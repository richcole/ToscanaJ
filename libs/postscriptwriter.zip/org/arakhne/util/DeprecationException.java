//   Copyright (C) 2002  St�phane Galland, Mahdi Hannoun
//
//   This library is free software; you can redistribute it and/or
//   modify it under the terms of the GNU Lesser General Public
//   License as published by the Free Software Foundation; either
//   version 2.1 of the License, or (at your option) any later version.
//
//   This library is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//   Lesser General Public License for more details.

//   You should have received a copy of the GNU Lesser General Public
//   License along with this library; if not, write to the Free Software
//   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//   This program is free software; you can redistribute it and/or modify

package org.arakhne.util ;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/** <var>DeprecationException</var> is the class of those exceptions
 *  that can be thrown when a deprecated element was used.
 *  <p>Because this is a
 *  {@link java.lang.RuntimeException RuntimeException}
 *  you don't need to declare this exception in the
 *  <code>throws</code> clause.
 *
 * \beginLog
 * \revision 02/03/25 0.2 St�phane Add internationalization
 * \revision 02/02/22 0.1 St�phane Initial release
 * \endLog
 *
 * @author St�phane Galland
 * @version 0.2, 02/03/25
 */
public class DeprecationException extends RuntimeException {

    /** <code>true</code> if deprecated exception
     *  could be thrown. If <code>false</code>,
     *  the exception was not generated.
     */
    public static boolean GENERATE_EXCEPTIONS = true ;

    /** Construct a new DeprecationException.
     *
     * @param cls is the deprecated class
     */
    public DeprecationException(Class cls) {
	super( "Deprecated class: " +
				   cls.toString() );
    }

    /** Construct a new DeprecationException.
     *
     * @param method is the deprecated method
     */
    public DeprecationException( Method method ) {
	super( "Deprecated method: " +
				   method.toString() );
    }

    /** Construct a new DeprecationException.
     *
     * @param field is the deprecated field
     */
    public DeprecationException( Field field ) {
	super( "Deprecated field: " +
				   field.toString() );
    }

    /** Construct a new DeprecationException.
     *
     * @param constructor is the deprecated constructor
     */
    public DeprecationException( Constructor constructor ) {
	super( "Deprecated constructor: " +
				   constructor.toString() );
    }

    /** Construct a new DeprecationException.
     *
     * @param obj is the deprecated constructor
     */
    public DeprecationException( Class cls, String name ) {
	super( "Deprecated attribute: " +
				   new Object[] {
				       cls.toString(),
				       name
				   } );
    }

}


///////////////////////////////////////////
// XEmacs macros
//
// Local Variables: 
// compile-command: "make -k classesall"
// End: 
