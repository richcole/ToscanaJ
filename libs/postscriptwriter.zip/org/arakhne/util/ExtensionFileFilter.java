// Copyright (C) 2002  St�phane Galland, Mahdi Hannoun
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; see the file COPYING.  If not, write to
// the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.

package org.arakhne.util ;

import java.io.File;
import java.util.Enumeration;
import java.util.Vector;

/** This class implements a file filter based
 *  on extensions specifications.
 *
 * \beginLog
 * \revision 02/01/22 0.2 St�phane Adds the method
 *             {@link #getBasename(File) getBasename()}
 * \revision 02/01/19 0.1 St�phane Initial release
 * \endLog
 *
 * @author St�phane Galland
 * @version 0.2, 02/01/22
 */
public class ExtensionFileFilter extends javax.swing.filechooser.FileFilter {

    ///////////////////////////////////////////////////////////
    // Attributes

    /** This is the list of extension supported by this filter.
     */
    protected Vector _filters = new Vector() ;

    /** This is the description of this filter.
     */
    protected String _description = null ;

    /** This is the full description of this filter.
     *  It includes the <var>_descrption</var> and
     *  the list of extensions.
     */
    private String _fullDescription = null ;

    ///////////////////////////////////////////////////////////
    // Constructors

    /** Create a new ExtensionFileFilter.
     */
    public ExtensionFileFilter() { }

    /** Create a new ExtensionFileFilter.
     *  <p>
     *  Note that the "." before the extension is not needed. If
     *  provided, it will be ignored.
     *
     * @param extension the extension to add to this filter.
     */
    public ExtensionFileFilter(String extension) {
	this(extension,null);
    }
 
    /** Create a new ExtensionFileFilter.
     *  <p>
     *  Note that the "." before the extension is not needed. If
     *  provided, it will be ignored.
     *
     * @param extension the extension to add to this filter.
     * @param description the description of the <var>extension</var>.
     */
    public ExtensionFileFilter(String extension, String description) {
	this();
	if (extension!=null) {
	    addExtension(extension);
	}
 	if (description!=null) {
	    setDescription(description);
	}
    }

    /** Create a new ExtensionFileFilter.
     *  <p>
     *  Note that the "." before the extensions is not needed. If
     *  provided, it will be ignored.
     *
     * @param filters a set of filters.
     */
    public ExtensionFileFilter(String[] filters) {
	this(filters, null);
    }

    /** Create a new ExtensionFileFilter.
     *  <p>
     *  Note that the "." before the extensions is not needed. If
     *  provided, it will be ignored.
     *
     * @param filters a set of filters.
     * @param description the description of the <var>filters</var>.
     */
    public ExtensionFileFilter(String[] filters, String description) {
	this();
	for (int i = 0; i < filters.length; i++) {
	    addExtension(filters[i]);
	}
 	if(description!=null) {
	    setDescription(description);
	}
    }

    ///////////////////////////////////////////////////////////
    // FileFilter API

    /** Reply if the given file matched this filter.
     *
     * @param file the file to check.
     * @return <code>true</code> if the <var>file</var>
     *         matched this filter, otherwise
     *         <code>false</code>.
     */
    public synchronized boolean accept(File file) {
	if (file != null) {
	    if (file.isDirectory()) {
		return true;
	    }
	    String extension = getExtension(file);
	    if (extension != null) {
		return _filters.contains( extension );
	    }
	}
	return false;
    }

    /** Return the extension portion of the file's name .
     *
     * @param file the file to check.
     * @return the extension of <var>file</var>.
     */
    public static String getExtension(File file) {
	if (file != null) {
	    String filename = file.getName();
	    int i = filename.lastIndexOf('.');
	    if ( (i>0) && (i<filename.length()-1) ) {
		return filename.substring(i+1).toLowerCase();
	    }
	}
	return null;
    }

    /** Return the file's name without its extension.
     *
     * @param file the file to check.
     * @return the basename of <var>file</var>.
     */
    public static String getBasename(File file) {
	if (file != null) {
	    String filename = file.getName();
	    int i = filename.lastIndexOf('.');
	    if ( (i>0) && (i<filename.length()-1) ) {
		return filename.substring(0, i);
	    }
	    else {
		return filename ;
	    }
	}
	return null;
    }

    ///////////////////////////////////////////////////////////
    // Extension API

    /** Adds an extension to this filter.
     *  <p>
     *  Note that the "." before the extensions is not needed. If
     *  provided, it will be ignored.
     *
     * @param extension the new extension
     */
    public synchronized void addExtension(String extension) {
	String ext = removePoint( extension.toLowerCase() ) ;
	if ( ext != null ) {
	    _filters.addElement( ext );
	    _fullDescription = null ;
	}
    }

    /** Replies a string without the point
     *  in the beggining if it exists.
     *
     * @param str the string to convert.
     * @return a string with a point in the beggining.
     */
    public static String removePoint( String str ) {
	if ( str.length() > 0 ) {
	    char c = str.charAt( 0 ) ;
	    if ( ( c == '.' ) && ( str.length() > 1 ) ) {
		return str.substring( 1 ) ;
	    }
	}
	return str ;
    }

    /** Replies the default extension for this filter.
     *  Usually, the default extention is the
     *  first added to this filter.
     *  <p>
     *  Note that the "." before the extensions will be
     *  automatically removed.
     *
     * @return the default extension of this filter,
     *         or <code>null</code>.
     */
    public synchronized String getDefaultExtension() {
	if ( ! _filters.isEmpty() ) {
	    return (String)_filters.get(0) ;
	}
	else {
	    return null ;
	}
    }


    /** Reply the description of this filter.
     *
     * @return the full description, if not exists
     *         returns the short description.
     */
    public synchronized String getDescription() {
	if ( _fullDescription == null ) {
	    if(_description == null) {
		_fullDescription = "" ;
	    }
	    else {
		_fullDescription = _description + " " ;
	    }
	    Enumeration enum = _filters.elements() ;
	    if ( enum.hasMoreElements() ) {
		_fullDescription += "(." + (String) enum.nextElement() ;
		while ( enum.hasMoreElements() ) {
		    _fullDescription += ", ." + (String) enum.nextElement() ;
		}
		_fullDescription += ")" ;
	    }
	}
	return _fullDescription ;
    }

    /** Sets the human readable description of this filter.
     *
     * @param the new description.
     */
    public synchronized void setDescription(String description) {
	_description = description ;
	_fullDescription = null ;
    }

}

///////////////////////////////////////////
// XEmacs macros
//
// Local Variables: 
// compile-command: "make -k classesall"
// End: 
