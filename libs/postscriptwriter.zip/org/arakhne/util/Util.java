//   Copyright (C) 2002  St�phane Galland, Mahdi Hannoun
//
//   This library is free software; you can redistribute it and/or
//   modify it under the terms of the GNU Lesser General Public
//   License as published by the Free Software Foundation; either
//   version 2.1 of the License, or (at your option) any later version.
//
//   This library is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//   Lesser General Public License for more details.

//   You should have received a copy of the GNU Lesser General Public
//   License along with this library; if not, write to the Free Software
//   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//   This program is free software; you can redistribute it and/or modify

package org.arakhne.util ;

import java.awt.Color;
import java.awt.Point;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.Enumeration;
import java.util.Vector;

/** This is a utility class.
 *
 * \beginLog
 * \revision 02/03/12 0.9 St�phane Adds the method
 *                        {@link #formatColor(Color) formatColor()}
 * \revision 02/05/24 0.8 St�phane Removes the functions that
 *                                 permits to computes some geometric
 *                                 values
 *                                 (use functions from 
 *                                 {@link java.awt.geom.Point2D Point2D} and
 *                                 {@link java.awt.geom.Line2D Line2D}
 *                                 instead).
 * \revision 02/03/28 0.7 St�phane Bug fix in the method
 *                        {@link #compareVersions(String,String) compareVersions()}
 * \revision 02/03/25 0.6 St�phane Add internationalization
 * \revision 02/03/12 0.5 St�phane Adds the method
 *                        {@link #compareVersions(String,String) compareVersions()}
 * \revision 02/02/22 0.4 St�phane Adds the method
 *                          {@link #cloneArrayOfPoints(Vector) cloneArrayOfPoints()}
 * \revision 02/02/17 0.3 St�phane Moves this class from
 *             <code>org.arakhne.neteditor.util</code>.
 * \revision 02/01/28 0.2 St�phane Adds the metric/inch methods
 * \revision 02/01/19 0.1 {St�phane &amp; Mahdi} Initial release
 * \endLog
 *
 * @author Mahdi Hannoun
 * @author St�phane Galland
 * @version 0.8, 02/03/25
 */
public class Util {

    /** No public constructor, this is a utility class with all static
     *  methods, so you never need an instance.
     */
    protected Util() {}

    /////////////////////////////////////////
    // Geometry API

    /** This is the maximale distance that
     *  permits to detect hits.
     */
    public static final double HIT_DISTANCE = 5.0 ;

    /** Normalize an angle.
     *  Translate the given angle (in radians) to force it
     *  to be between 0 and 2*PI.
     *
     * @param angle the angle to normalize.
     * @return an angle (in radians) that is normalized.
     */
    public static final double normalizeAngle( double angle ) {
	if ( angle >= 0.0 ) {
	    while ( angle >= (2.0*Math.PI) ) {
		angle -= 2.0 * Math.PI;
	    }
	}
	else {
	    while ( angle < 0 ) {
		angle += 2.0 * Math.PI;
	    }	    
	}
	return angle;
    }

    /** Return the trigonometric angle of a vector.
     *  The vector is from the first point to the
     *  second point.
     *  The point (<var>x1</var>,<var>y1</var>) is the
     *  origin of the trigonometric space.
     *  The resulting angle is normalized with
     *  {@link #normalizeAngle(double) normalizeAngle()}.
     *
     * @param x1 x coordinate of the first point.
     * @param y1 y coordinate of the first point.
     * @param x2 x coordinate of the second point.
     * @param y2 y coordinate of the seoond point.
     * @return the troginometric angle in radians of the given vector,
     *         or <code>Math.NaN</code> if an error occurs.
     */
    public static final double getAngleFromVector( int x1, int y1, int x2, int y2 ) {
	return getAngleFromVector( (double)x1, (double)y1,
				   (double)x2, (double)y2 ) ;
    }

    /** Return the trigonometric angle of a vector.
     *  The vector is from the first point to the
     *  second point.
     *  The point (<var>x1</var>,<var>y1</var>) is the
     *  origin of the trigonometric space.
     *  The resulting angle is normalized with
     *  {@link #normalizeAngle(double) normalizeAngle()}.
     *
     * @param x1 x coordinate of the first point.
     * @param y1 y coordinate of the first point.
     * @param x2 x coordinate of the second point.
     * @param y2 y coordinate of the seoond point.
     * @return the troginometric angle in radians of the given vector,
     *         or <code>Math.NaN</code> if an error occurs.
     */
    public static final double getAngleFromVector( double x1, double y1, double x2, double y2 ) {
	double vector_x = x2 - x1 ;
	double vector_y = y2 - y1 ;
	double norme = Math.sqrt( vector_x * vector_x + vector_y * vector_y ) ;
	double angle = Double.NaN ;
	if ( norme != 0.0 ) {
	    vector_y = vector_y / norme ;
	    angle = Math.asin( vector_y ) ;
	    if ( x2 < x1 ) angle = Math.PI - angle ;
	}
	return normalizeAngle( angle ) ;
    }

    /** Return the trofinometric angle of a vector.
     *  The vector is from the first point to the
     *  second point.
     *  The point <var>p1</var> is the
     *  origin of the trigonometric space.
     *  The resulting angle is normalized with
     *  {@link #normalizeAngle(double) normalizeAngle()}.
     *
     * @param p1 first point.
     * @param dpx2 second point.
     * @return the troginometric angle in radians of the given vector,
     *         or <code>Math.NaN</code> if an error occurs.
     */
    public static final double getAngleFromVector( Point p1, Point p2 ) {
	return getAngleFromVector( p1.x, p1.y, p2.x, p2.y );
    }

    /** Return the trofinometric angle of a vector.
     *  The vector is from the first point to the
     *  second point.
     *  The point <var>p1</var> is the
     *  origin of the trigonometric space.
     *  The resulting angle is normalized with
     *  {@link #normalizeAngle(double) normalizeAngle()}.
     *
     * @param p1 first point.
     * @param dpx2 second point.
     * @return the troginometric angle in radians of the given vector,
     *         or <code>Math.NaN</code> if an error occurs.
     */
    public static final double getAngleFromVector( Point2D p1, Point2D p2 ) {
	return getAngleFromVector( p1.getX(), p1.getY(), p2.getX(), p2.getY() );
    }

    /** Replies if a point is closed to a line.
     *  The maximale distance is
     *  {@link #HIT_DISTANCE HIT_DISTANCE}.
     *
     * @param x1 horizontal location of the first line begining.
     * @param y1 vertical location of the first line begining.
     * @param x2 horizontal location of the second line ending.
     * @param y2 vertical location of the second line ending.
     * @param x horizontal location of the point.
     * @param y vertical location of the point.
     * @return <code>true</code> if the point and the
     *         line have closed locations.
     */
    public static boolean pointClosedToLine( double x1, double y1, 
					     double x2, double y2, 
					     double x, double y ) {
	return ( Line2D.ptSegDist( x1, y1, 
				   x2, y2, 
				   x,  y ) < HIT_DISTANCE ) ;
    }

    /** Replies the director coef of a line
     *
     * @param l is the line
     * @return the director coef of the specified line,
     *         or <code>Double.NaN</code>.
     * @since 0.8
     */
    public static double getDirCoef( Line2D l ) {
	if ( l.getX1() == l.getX2() ) {
	    return Double.NaN ;
	}
	else {
	    return ( l.getY1() - l.getY2() ) / ( l.getX1() - l.getX2() ) ;
	}
    }

    /** Replies the intersection point of two lines.
     *
     * @param l1 is the first line
     * @param l2 is the second line
     * @return the intersection point or <code>null</code>.
     * @since 0.8
     */
    public static Point2D getIntersection( Line2D l1, Line2D l2 ) {
	if ( l2.intersectsLine( l1 ) ) {
	    // equation of l1: y = a1.x+b1
	    // equation of l2: y = a2.x+b2
	    double a1 = getDirCoef( l1 ) ;
	    double a2 = getDirCoef( l2 ) ;

	    if ( ( ! Double.isNaN( a1 ) ) ||
		 ( ! Double.isNaN( a2 ) ) ) {

		// compute the second coef
		double b1=0f, b2=0f ;

		if ( ! Double.isNaN( a1 ) ) {
		    b1 = l1.getY1() - a1 * l1.getX1() ;
		}

		if ( ! Double.isNaN( a2 ) ) {
		    b2 = l2.getY1() - a2 * l2.getX1() ;
		}

		// computes the coords of the intersection
		double x, y ;

		if ( Double.isNaN( a1 ) ) {
		    x = l1.getX1() ;
		    y = a2 * x + b2 ;
		}
		else if ( Double.isNaN( a2 ) ) {
		    x = l2.getX1() ;
		    y = a1 * x + b1 ;
		}
		else if ( a1 == a2 ) {
		    return null ;
		}
		else {
		    x = (b2 - b1) / (a1 - a2) ;
		    y = a1 * x + b1 ;
		}

		Point2D p = new Point2D.Double(x,y) ;
		return p ;

		    
	    }    
	    else {
		return l2.getP1() ;
	    }
	    
	}
	return null ;
    }

    /** Replies the intersection point of a line and a rectangle.
     *
     * @param l is the line
     * @param r is the rectangle
     * @return the intersection point or <code>null</code>.
     * @since 0.8
     */
    public static Point2D getIntersection( Line2D l, Rectangle2D r ) {
	double x1 = r.getX() ;
	double y1 = r.getY() ;
	double x2 = x1 + r.getWidth() ;
	double y2 = y1 + r.getHeight() ;
	Point2D i = getIntersection( l, new Line2D.Double( x1, y1, x2, y1 ) ) ;
	if ( i == null ) {
	    i = getIntersection( l, new Line2D.Double( x2, y1, x2, y2 ) ) ;
	}
	if ( i == null ) {
	    i = getIntersection( l, new Line2D.Double( x2, y2, x1, y2 ) ) ;
	}
	if ( i == null ) {
	    i = getIntersection( l, new Line2D.Double( x1, y2, x1, y1 ) ) ;
	}
	return i ;
    }

    /////////////////////////////////////
    // Convertion API

    /** Replies the metrics from inches.
     *
     * @param i the inch value
     * @return a value in centimeters
     */
    public static float inchToMetric( float i ) {
	return i / 0.3937f ;
    }

    /** Replies the inches from metrics.
     *
     * @param m the metric value
     * @return a value in inches
     */
    public static float metricToInch( float m ) {
	return m * 0.3937f ;
    }

    ////////////////////////////////////////
    // Picture tools

    /** Replies a copy of the specified parameter.
     *  We assume that all elements of <var>v</var>
     *  are {@link java.awt.geom.Point2D Point2D}.
     *  <p>
     *  This method create a new vector that contains
     *  clones of each elements of <var>v</var>.
     *
     * @param v is the vector of points to clone.
     * @return a vector that contains clones of
     *         <var>v</var>'s elements.
     * @since 0.4
     */
    public static final Vector cloneArrayOfPoints( Vector v ) {
	Vector clone_of_v = new Vector() ;
	Enumeration enum = v.elements() ;
	while ( enum.hasMoreElements() ) {
	    Object obj = enum.nextElement() ;
	    if ( obj instanceof Point ) {
		clone_of_v.addElement( new Point( ((Point)obj).x,
						  ((Point)obj).y ) ) ;
	    }
	    else {
		clone_of_v.addElement( new Point2D.Double( ((Point2D)obj).getX(),
							   ((Point2D)obj).getY() ) ) ;
	    }
	}
	return clone_of_v ;
    }

    ///////////////////////////////////////////
    // Other functions

    /** Compares lexicographycally the two
     *  specified string, which
     *  contains versions numbers.
     *  <p>
     *  A version number is list of numbers
     *  separated by points.
     *  <p>
     *  Example: <code>0.2.3</code>
     *  <p>
     *  <Strong>Note:</strong>&nbsp; a tag field
     *  is not allowed.
     *
     * @param v1 first version number to compare
     * @param v2 second version number to compare
     * @return a negative value if <var>v1</var>
     *         is older than <var>v2</var>, <code>0</code>
     *         if the two versions are equals, and
     *         a positive value if <var>v1</var>
     *         is newer than <var>v2</var>
     * @since 0.5
     */
    public static int compareVersions( String v1, String v2 ) {
	if ( "".equals( v1 ) ) {
	    if ( "".equals( v2 ) ) {
		return 0 ;
	    }
	    else {
		return -1 ;
	    }
	}
	else if ( "".equals( v2 ) ) {
	    return 1 ;
	}
	int i1 = v1.indexOf('.') ;
	int i2 = v2.indexOf('.') ;
	String n1, n2 ;
	String f1, f2 ;
	// Gets the values of the first version's components.
	if ( i1 >= 0 ) {
	    n1 = v1.substring( 0, i1-1 ) ;
	    f1 = v1.substring( i1 + 1 ) ;
	}
	else {
	    n1 = v1 ;
	    f1 = new String("") ;
	}
	if ( i2 >= 0 ) {
	    n2 = v2.substring( 0, i2-1 ) ;
	    f2 = v2.substring( i2 + 1 ) ;
	}
	else {
	    n2 = v2 ;
	    f2 = new String("") ;
	}
	// Compares the extracted version's components
	int r = n1.compareTo( n2 ) ;
	if ( r == 0 ) {
	    return compareVersions( f1, f2 ) ;
	}
	else {
	    return r ;
	}	
    }

    /** Reply a string representation of the specified color.
     *
     * @param c the color to translate
     * @return a string representation of <code>c</code>.
     * @since 0.9
     */
    public static String formatColor( Color c ) {
	if ( c == null ) {
	    return "??????" ;
	}
	String hex = Integer.toHexString( c.getRGB() & 0xffffff ) ;
	while ( hex.length() < 6 ) {
	    hex = "0" + hex ;
	}
	return hex ;
    }

}


///////////////////////////////////////////
// XEmacs macros
//
// Local Variables: 
// compile-command: "make -k classesall"
// End: 
