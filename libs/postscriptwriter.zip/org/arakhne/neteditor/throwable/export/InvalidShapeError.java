//   Copyright (C) 2002  St�phane Galland, Mahdi Hannoun
//
//   This library is free software; you can redistribute it and/or
//   modify it under the terms of the GNU Lesser General Public
//   License as published by the Free Software Foundation; either
//   version 2.1 of the License, or (at your option) any later version.
//
//   This library is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//   Lesser General Public License for more details.

//   You should have received a copy of the GNU Lesser General Public
//   License along with this library; if not, write to the Free Software
//   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//   This program is free software; you can redistribute it and/or modify

package org.arakhne.neteditor.throwable.export ;

/** <var>InvalidShapeError</var> is the class of those exceptions
 *  that can be thrown when the exporter found a shape that
 *  it knows nothing about how to export.
 *  can't be accessed.
 *
 * \beginLog
 * \revision 02/05/16 0.1 St�phane First release
 * \endLog
 *
 * @author St�phane Galland
 * @version 0.1, 02/05/16
 */
public class InvalidShapeError extends ExporterError {

    /** Construct a new InvalidShapeError.
     *
     * @param shapeClass is the class of the shape.
     */
    public InvalidShapeError(Class shapeClass) {
	super( "Shape not supported: " +
				   shapeClass.getName() ) ;
    }
}


///////////////////////////////////////////
// XEmacs macros
//
// Local Variables: 
// compile-command: "make -k classesall"
// End: 
