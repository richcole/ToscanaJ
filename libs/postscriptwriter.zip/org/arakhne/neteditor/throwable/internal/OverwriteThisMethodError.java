//   Copyright (C) 2002  St�phane Galland, Mahdi Hannoun
//
//   This library is free software; you can redistribute it and/or
//   modify it under the terms of the GNU Lesser General Public
//   License as published by the Free Software Foundation; either
//   version 2.1 of the License, or (at your option) any later version.
//
//   This library is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//   Lesser General Public License for more details.

//   You should have received a copy of the GNU Lesser General Public
//   License along with this library; if not, write to the Free Software
//   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//   This program is free software; you can redistribute it and/or modify

package org.arakhne.neteditor.throwable.internal ;

/** <var>OverwriteThisMethod</var> is the class of those exceptions
 *  that can be thrown when an internal error of NetEditor occurs.
 *  <p>Because this is a
 *  {@link java.lang.RuntimeException RuntimeException}
 *  you don't need to declare this exception in the
 *  <code>throws</code> clause.
 *
 * \beginLog
 * \revision 02/01/19 0.1 St�phane Initial release
 * \endLog
 *
 * @author St�phane Galland
 * @version 0.1, 02/01/19
 */
public class OverwriteThisMethodError extends InternalError {

    /** Construct a new OverwriteThisMethodError.
     *
     * @param cls is the name in which the method must be overwrite.
     * @param methodname is the name of the overwriteable method.
     */
    public OverwriteThisMethodError(Class cls, String methodname) {
	super( "Must be overwritten:"+"\n"+
	       cls.getName()+"."+methodname+"()" );
    }

    /** Construct a new OverwriteThisMethodError.
     */
    public OverwriteThisMethodError() {
	super("Must be overwritten.");
    }

}


///////////////////////////////////////////
// XEmacs macros
//
// Local Variables: 
// compile-command: "make -k classesall"
// End: 
