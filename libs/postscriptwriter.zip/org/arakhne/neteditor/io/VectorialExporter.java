//   Copyright (C) 2002  St�phane Galland, Mahdi Hannoun
//
//   This library is free software; you can redistribute it and/or
//   modify it under the terms of the GNU Lesser General Public
//   License as published by the Free Software Foundation; either
//   version 2.1 of the License, or (at your option) any later version.
//
//   This library is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//   Lesser General Public License for more details.

//   You should have received a copy of the GNU Lesser General Public
//   License along with this library; if not, write to the Free Software
//   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//   This program is free software; you can redistribute it and/or modify

package org.arakhne.neteditor.io ;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.font.TextAttribute;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.awt.geom.CubicCurve2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.QuadCurve2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ImageObserver;
import java.awt.image.PixelGrabber;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderableImage;
import java.io.File;
import java.io.OutputStream;
import java.text.AttributedCharacterIterator;
import java.text.CharacterIterator;
import java.util.Hashtable;
import java.util.Map;

import org.arakhne.neteditor.throwable.export.AbordPictureGenerationError;
import org.arakhne.neteditor.throwable.export.InvalidShapeError;
import org.arakhne.neteditor.throwable.internal.OverwriteThisMethodError;
import org.arakhne.util.DeprecationException;
import org.arakhne.util.Util;

/** This graphic context permits to export
 *  from a graphic context.
 *  <p><center>
 *    <img src="doc-files/VectorialExporter_uml.png" border="0">
 *  </center>
 *
 * \beginLog
 * \revision 02/05/27 0.5 St�phane deprecates the FontMetrics 
 *                        functions, because I don't know how
 *                        to implement them until now, and
 *                        fixes bugs on string drawing.
 * \revision 02/03/24 0.4 St�phane Adds internationalization
 * \revision 02/03/12 0.3 St�phane Adds some methods to set the properties
 *                                 of this exporter.
 * \revision 02/02/17 0.2 St�phane Fixes bugs about bitmap generation
 * \revision 02/01/29 0.1 St�phane Initial release
 * \endLog
 *
 * @author St�phane Galland
 * @version 0.5, 02/03/25
 */
public abstract class VectorialExporter extends Graphics2D {

    ////////////////////////////////////////////////////////////
    // Attributes

    /** The maximum distance that the line 
     *  segments used to approximate the 
     *  curved segments are allowed to 
     *  deviate from any point on the 
     *  original curve.
     *  <p>
     *  This attributes is used to parameter the approximation
     *  of the curve rendering.
     */
    private double __curveApproxRatio = 0.1 ;

    /** Says if this exporter must
     *  approximate the curves.
     *  If <code>true</code>, each curve is
     *  discretized according to
     *  {@link #__curveApproxRatio the approximation ratio}.
     *  If <code>false</code>, this exporter calls
     *  {@link #_veDrawCurve(CubicCurve2D,Color) _veDrawCurve(CubicCurve2D)} or
     *  {@link #_veDrawCurve(QuadCurve2D,Color) _veDrawCurve(QuadCurve2D)}.
     */
    private final boolean __approxCurves ;

    /** Background color.
     */
    private Color __backgroundColor = Color.white ;

    /** Background color.
     *  We assume that this color is always solid
     *  (no <code>java.awt.GradientPaint</code> or
     *  <code>java.awt.TexturePaint</code>).
     */
    private Color __currentColor = Color.black ;

    /** Current affine transformation.
     */
    private AffineTransform __affineTransform = new AffineTransform() ;

    /** Current clipping rectangle.
     *  We assume that the clipping area was always a rectangle.
     */
    private Rectangle2D __currentClip = null ;

    /** Current Font.
     */
    private Font __currentFont = new Font( "Helvetica", Font.PLAIN, 12 ) ;

    /** Current preferences for the rendering algorithmes.
     */
    private RenderingHints __renderPrefs = new RenderingHints( new Hashtable() )  ;

    /** Current outlining stoke.
     */
    private Stroke __currentStroke = new BasicStroke() ;

    /** Current composite.
     */
    private Composite __currentComposite = AlphaComposite.SrcOver ;

    ////////////////////////////////////////////////////////////
    // Constructor
    
    /** Construct a new VectorialExporter.
     */
    protected VectorialExporter() {
	__approxCurves = true ;
    }

    /** Construct a new VectorialExporter.
     *
     * @param approxCurves <code>true</code> if curbes must
     *                     be discretized.
     */
    protected VectorialExporter( boolean approxCurves ) {
	__approxCurves = approxCurves ;
    }

    /** Construct a new VectorialExporter.
     *
     * @param ve the vectorial context to copy.
     */
    protected VectorialExporter( VectorialExporter ve ) {
	__curveApproxRatio = ve.__curveApproxRatio ;
	__approxCurves = ve.__approxCurves ;
	__backgroundColor = ve.__backgroundColor ;
	__currentColor = ve.__currentColor ;
	__affineTransform = new AffineTransform( ve.__affineTransform ) ;
	ve.__currentClip = ve.__currentClip ;
	__renderPrefs = new RenderingHints( ve.__renderPrefs ) ;
	__currentStroke = ve.__currentStroke ;
	__currentComposite = ve.__currentComposite ;
    }

    ////////////////////////////////////////////////////////////
    // VectorialExporter API

    /** Sets the drawing area used to export the document.
     *  See subclasses for more details about the use of
     *  the drawing area.
     *
     * @param r is the drawing area in which the document must
     *          be exported.
     * @since 0.3
     */
    public abstract void setDrawingArea( Rectangle r ) ;

    /** Sets the target file. See subclasses for more
     *  details about the use of the target filename.
     *
     * @param os is the output stream.
     * @param f the name of the target file.
     */
    public abstract void setTargetFile( OutputStream os, File f ) ;

    /** Exports the prolog for this document.
     *  See subclasses for more details.
     * 
     * @since 0.3
     */
    public abstract void exportProlog() ;

    /** Does this exporter must discretize the curves?
     *
     *  @return <code>true</code> if each curve is
     *          discretized according to
     *          {@link #__curveApproxRatio the approximation ratio}.
     *          <code>false</code> if this exporter calls
     *          {@link #_veDrawCurve(CubicCurve2D,Color) _veDrawCurve(CubicCurve2D)} or
     *          {@link #_veDrawCurve(QuadCurve2D,Color) _veDrawCurve(QuadCurve2D)}.
     */
    public boolean isDiscretizedCurves() {
	return __approxCurves ;
    }

    /** Sets the discretization ration for curves.
     *
     * @param ratio the maximum distance that the line 
     *              segments used to approximate the 
     *              curved segments are allowed to 
     *              deviate from any point on the 
     *              original curve.
     * @see Shape#getPathIterator(AffineTransform,double)
     */
    public void setDiscretizedCurveRatio( double ratio ) {
	__curveApproxRatio = ratio ;	
    }

    /** Replies the discretization ration for curves.
     *
     * @return the maximum distance that the line 
     *         segments used to approximate the 
     *         curved segments are allowed to 
     *         deviate from any point on the 
     *         original curve.
     * @see Shape#getPathIterator(AffineTransform,double)
     */
    public double getDiscretizedCurveRatio() {
	return __curveApproxRatio ;	
    }

    ////////////////////////////////////////////////////////////
    // Graphics API

    /** Clears the specified rectangle by filling with the 
     *  background color.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param x x coordinate of the rectangle
     * @param y y coordinate of the rectangle
     * @param width the width of the rectangle
     * @param height the height of the rectangle
     */
    public void clearRect( int x, int y, int width, int height ) {
	Rectangle r = new Rectangle( x, y, width, height ) ;
	__fillShape( __affineTransform.createTransformedShape( r ), 
		     __backgroundColor ) ;
    }

    /** Intersects the current clip with the specified rectangle.
     *  <p>
     *  The given coordinates will <em>not</em> be transformed.
     *
     * @param x x coordinate of the rectangle
     * @param y y coordinate of the rectangle
     * @param width the width of the rectangle
     * @param height the height of the rectangle	
     */
    public void clipRect( int x, int y, int width, int height ) {
	if ( __currentClip == null ) {
	    __currentClip = new Rectangle( x, y, width, height ) ;
	}
	else {
	    __currentClip = __currentClip.createIntersection( new Rectangle( x, y, width, height ) ) ;
	}
	_veSetClip( __currentClip ) ;
    }

    /** Copies an area of the component by a distance of 
     *  specified <var>dx</var> and <var>dy</var>.
     *  <p>
     *  This method is not supported in a vectorial context.
     *
     * @param x x coordinate of the area
     * @param y y coordinate of the area
     * @param width the width of the area
     * @param height the height of the area
     * @param dx horizontal translation
     * @param dy vertical translation
     */
    public void copyArea( int x, int y, int width, int height, int dx, int dy ) {
    }

    /** Draws the outline of an arc.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param x x coordinate of the covered rectangle
     * @param y y coordinate of the covered rectangle
     * @param width the width of the covered rectangle
     * @param height the height of the covered rectangle
     * @param startAngle the starting angle
     * @param arcAngle the size of the arc
     */
    public void drawArc( int x, int y, int width, int height, int startAngle, int arcAngle ) {
	Arc2D a = new Arc2D.Float( (float)x, 
				   (float)y, 
				   (float)width, 
				   (float)height,
				   (float)startAngle,
				   (float)arcAngle,
				   Arc2D.OPEN ) ;
	__drawShape( __affineTransform.createTransformedShape( a ), 
		     __currentColor ) ;
    }

    /** Draws the specified image.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param img the image
     * @param x horizontal location of the image
     * @param y vertical location of the image
     * @param bgColor the color of transparent pixels
     * @param obs the notified observer
     * @return <code>true</code> if theimage wascomplety drawn.
     */
    public boolean drawImage( Image img, int x, int y, Color bgcolor, ImageObserver obs ) {
	AffineTransform at = new AffineTransform( __affineTransform ) ;
	at.translate( x, y ) ;
	return __drawImage( img, at, bgcolor, obs ) ;
    }

    /** Draws the specified image.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param img the image
     * @param x horizontal location of the image
     * @param y vertical location of the image
     * @param obs the notified observer
     * @return <code>true</code> if theimage wascomplety drawn.
     */
    public boolean drawImage( Image img, int x, int y, ImageObserver obs ) {
	return drawImage( img, x, y, null, obs ) ;
    }

    /** Draws the specified image. Scales it if necessary.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param img the image
     * @param x horizontal location of the image
     * @param y vertical location of the image
     * @param width width of the image
     * @param height height of the image
     * @param bgColor the color of transparent pixels
     * @param obs the notified observer
     * @return <code>true</code> if theimage wascomplety drawn.
     */
    public boolean drawImage( Image img, int x, int y, int width, int height, Color bgColor, ImageObserver obs ) {
	AffineTransform at = new AffineTransform( __affineTransform ) ;
	at.translate( x, y ) ;
	at.scale( width, height ) ;
	return __drawImage( img, at, bgColor, obs ) ;
    }

    /** Draws the specified image. Scales it if necessary.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param img the image
     * @param x horizontal location of the image
     * @param y vertical location of the image
     * @param width width of the image
     * @param height height of the image
     * @param obs the notified observer
     * @return <code>true</code> if theimage wascomplety drawn.
     */
    public boolean drawImage( Image img, int x, int y, int width, int height, ImageObserver obs ) {
	return drawImage( img, x, y, width, height, null, obs ) ;
    }

    /** Draws a part of the specified image into
     *  the given rectangle. Scales it if necessary.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param img the image
     * @param dx1 horizontal location of the target image upper left corner
     * @param dy1 vertical location of the target image upper left corner
     * @param dx2 horizontal location of the target image lower right corner
     * @param dy2 vertical location of the target image lower right corner
     * @param sx1 horizontal location of the source image upper left corner
     * @param sy1 vertical location of the source image upper left corner
     * @param sx2 horizontal location of the source image lower right corner
     * @param sy2 vertical location of the source image lower right corner
     * @param bgColor the color of transparent pixels
     * @param obs the notified observer
     * @return <code>true</code> if theimage wascomplety drawn.
     */
    public boolean drawImage( Image img, 
			      int dx1, int dy1, 
			      int dx2, int dy2,
			      int sx1, int sy1,
			      int sx2, int sy2,
			      Color bgColor,
			      ImageObserver obs ) {
	// Get the pixels of the image
	int width = sx2 - sx1 + 1 ;
	int height = sy2 - sy1 + 1 ;
        int[] pixels = new int[width * height];
        PixelGrabber pg = new PixelGrabber( img, 
					    sx1, sy1, 
					    width, 
					    height, 
					    pixels, 
					    0, width);
        try {
            pg.grabPixels();
        } 
	catch (InterruptedException e) {
            throw new AbordPictureGenerationError();
        }        
	if ((pg.getStatus() & ImageObserver.ABORT) != 0) {
	    throw new AbordPictureGenerationError();
        }
	
	// Creates the new image
        BufferedImage subimg = new BufferedImage( width, height, 
						  BufferedImage.TYPE_INT_ARGB ) ;
        for (int j = 0; j < height; j++) {
            for (int i = 0; i < width; i++) {
                subimg.setRGB( i, j, pixels[j * width + i] );
            }
        }
	subimg.flush() ;
	// Draws the new image
	AffineTransform at = new AffineTransform( __affineTransform ) ;
	at.translate( dx1, dy1 ) ;
	at.scale( dx2 - dx1 + 1, dy2 - dy1 + 1 ) ;
	return __drawImage( subimg, at, bgColor, obs ) ;
    }

    /** Draws a part of the specified image into
     *  the given rectangle. Scales it if necessary.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param img the image
     * @param dx1 horizontal location of the target image upper left corner
     * @param dy1 vertical location of the target image upper left corner
     * @param dx2 horizontal location of the target image lower right corner
     * @param dy2 vertical location of the target image lower right corner
     * @param sx1 horizontal location of the source image upper left corner
     * @param sy1 vertical location of the source image upper left corner
     * @param sx2 horizontal location of the source image lower right corner
     * @param sy2 vertical location of the source image lower right corner
     * @param obs the notified observer
     * @return <code>true</code> if theimage wascomplety drawn.
     */
    public boolean drawImage( Image img, 
			      int dx1, int dy1, 
			      int dx2, int dy2,
			      int sx1, int sy1,
			      int sx2, int sy2,
			      ImageObserver obs ) {
	return drawImage( img, 
			  dx1, dy1, dx2, dy2,
			  sx1, sy1, sx2, sy2,
			  null, obs ) ;
    }

    /** Draws a line, using the current color, between
     *  (<var>x1</var>,<var>y1</var>) and 
     *  (<var>x2</var>,<var>y2</var>).
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param x1 horizontal location of the start point.
     * @param y1 vertical location of the start point.
     * @param x2 horizontal location of the target point.
     * @param y2 vertical location of the target point.
     */
    public void drawLine( int x1, int y1, int x2, int y2 ) {
	Line2D l = new Line2D.Float( (float)x1, 
				     (float)y1, 
				     (float)x2, 
				     (float)y2 ) ; 
	__drawShape( __affineTransform.createTransformedShape( l ), 
		     __currentColor ) ;
    }

    /** Draws an oval, using the current color, inside
     *  the specified rectangle.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param x horizontal location of the enclosing rectangle.
     * @param y vertical location of the enclosing rectangle.
     * @param w width of the enclosing rectangle.
     * @param h height of the enclosing rectangle.
     */
    public void drawOval( int x, int y, int w, int h ) {
	Ellipse2D e = new Ellipse2D.Float( (float)x, 
					   (float)y, 
					   (float)w, 
					   (float)h ) ; 
	__drawShape( __affineTransform.createTransformedShape( e ), 
		     __currentColor ) ;
    }

    /** Draws a polygon, using the current color.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param xPoints horizontal coordiantes of points.
     * @param yPoints vertical coordiantes of points.
     * @param nPoints count of points in the polygon.
     */
    public void drawPolygon( int[] xPoints, int[] yPoints, int nPoints ) {
	Polygon p = new Polygon( xPoints, yPoints, nPoints ) ;
	__drawShape( __affineTransform.createTransformedShape( p ), 
		     __currentColor ) ;
    }

    /** Draws a polyline, using the current color.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param xPoints horizontal coordiantes of points.
     * @param yPoints vertical coordiantes of points.
     * @param nPoints count of points in the polyline.
     */
    public void drawPolyline( int[] xPoints, int[] yPoints, int nPoints ) {
	// Builds the general path corresponding to the polyline
	GeneralPath gp = new GeneralPath() ;
	for( int i=0; i<nPoints; i++) {
	    if ( i==0 ) {
		gp.moveTo( xPoints[i], yPoints[i] ) ;
	    }
	    else {
		gp.lineTo( xPoints[i], yPoints[i] ) ;
	    }
	}
	// Draws the polyline
	__drawShape( __affineTransform.createTransformedShape( gp ), 
		     __currentColor ) ;
    }

    /** Draws the outline of a rounded-rectangle.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param x horizontal location of the rectangle.
     * @param y vertical location of the rectangle.
     * @param w width of the rectangle.
     * @param h height of the rectangle.
     * @param arcWidth width of the corners' angle.
     * @param arcHeight height of the corners' angle.
     */
    public void drawRoundRect( int x, int y, int w, int h, int arcWidth, int arcHeight ) {
	RoundRectangle2D rr = new RoundRectangle2D.Float( (float)x, 
							  (float)y, 
							  (float)w, 
							  (float)h,
							  (float)arcWidth,
							  (float)arcHeight ) ; 
	__drawShape( __affineTransform.createTransformedShape( rr ), 
		     __currentColor ) ;
    }

    /** Fills an arc.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param x x coordinate of the covered rectangle
     * @param y y coordinate of the covered rectangle
     * @param width the width of the covered rectangle
     * @param height the height of the covered rectangle
     * @param startAngle the starting angle
     * @param arcAngle the size of the arc
     */
    public void fillArc( int x, int y, int width, int height, int startAngle, int arcAngle ) {
	Arc2D a = new Arc2D.Float( (float)x, 
				   (float)y, 
				   (float)width, 
				   (float)height,
				   (float)startAngle,
				   (float)arcAngle,
				   Arc2D.OPEN ) ;
	__fillShape( __affineTransform.createTransformedShape( a ), 
		     __currentColor ) ;
    }

    /** fills an oval, using the current color, inside
     *  the specified rectangle.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param x horizontal location of the enclosing rectangle.
     * @param y vertical location of the enclosing rectangle.
     * @param w width of the enclosing rectangle.
     * @param h height of the enclosing rectangle.
     */
    public void fillOval( int x, int y, int w, int h ) {
	Ellipse2D e = new Ellipse2D.Float( (float)x, 
					   (float)y, 
					   (float)w, 
					   (float)h ) ; 
	__fillShape( __affineTransform.createTransformedShape( e ), 
		     __currentColor ) ;
    }

    /** Fills a polygon, using the current color.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param xPoints horizontal coordiantes of points.
     * @param yPoints vertical coordiantes of points.
     * @param nPoints count of points in the polygon.
     */
    public void fillPolygon( int[] xPoints, int[] yPoints, int nPoints ) {
	Polygon p = new Polygon( xPoints, yPoints, nPoints ) ;
	__fillShape( __affineTransform.createTransformedShape( p ), 
		     __currentColor ) ;
    }

    /** Fills a rectangle..
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param x horizontal location of the rectangle.
     * @param y vertical location of the rectangle.
     * @param w width of the rectangle.
     * @param h height of the rectangle.
     */
    public void fillRect( int x, int y, int w, int h ) {
	Rectangle2D r = new Rectangle2D.Float( (float)x, 
					       (float)y, 
					       (float)w, 
					       (float)h ) ;
	__fillShape( __affineTransform.createTransformedShape( r ), 
		     __currentColor ) ;
    }

    /** Fills a rounded-rectangle.
     *  <p>
     *  The given coordinates will be transformed.
     *
     * @param x horizontal location of the rectangle.
     * @param y vertical location of the rectangle.
     * @param w width of the rectangle.
     * @param h height of the rectangle.
     * @param arcWidth width of the corners' angle.
     * @param arcHeight height of the corners' angle.
     */
    public void fillRoundRect( int x, int y, int w, int h, int arcWidth, int arcHeight ) {
	RoundRectangle2D rr = new RoundRectangle2D.Float( (float)x, 
							  (float)y, 
							  (float)w, 
							  (float)h,
							  (float)arcWidth,
							  (float)arcHeight ) ; 
	__fillShape( __affineTransform.createTransformedShape( rr ), 
		     __currentColor ) ;
    }

    /** Replies the current clipping area.
     *
     * @return the current clipping area.
     */
    public Shape getClip() {
	if ( __currentClip == null ) {
	    return new Rectangle();
	}
	else {
	    return __currentClip ;
	}
    }

    /** Replies the bounds of the current clipping area.
     *
     * @return bounds.
     */
    public Rectangle getClipBounds() {
	return getClip().getBounds() ;
    }

    /** Replies the current color.
     *
     * @return the current foreground color.
     */
    public Color getColor() {
	return __currentColor ;
    }

    /** Replies the current font.
     *
     * @return the current {@link Font Font}.
     */
    public Font getFont() {
	return __currentFont ;
    }

    /** Replies the current font metrics.
     *
     * @return the current {@link FontMetrics metrics}.
     * @deprecated use <code>java.awt.Font.getLineMetrics()</code>
     */
    public FontMetrics getFontMetrics() {
	if ( DeprecationException.GENERATE_EXCEPTIONS ) {
	    throw new DeprecationException( getClass(),
					    "getFontMetrics()" ) ;
	}
	return getFontMetrics( __currentFont ) ;
    }

    /** Replies the font metrics for the specified font.
     *
     * @param font the font to use.
     * @return the current {@link FontMetrics metrics}.
     * @deprecated use <code>java.awt.Font.getLineMetrics()</code>
     */
    public FontMetrics getFontMetrics(Font font) {
	if ( DeprecationException.GENERATE_EXCEPTIONS ) {
	    throw new DeprecationException( getClass(),
					    "getFontMetrics(Font)" ) ;
	}
	return null ;
    }

    /** Sets the current clipping area.
     *
     * @param x horizontal location of the rectangle.
     * @param y vertical location of the rectangle.
     * @param w width of the rectangle.
     * @param h height of the rectangle.
     */
    public void setClip( int x, int y, int width, int height ) {
	__currentClip = new Rectangle( x, y, width, height ) ;	
	_veSetClip( __currentClip ) ;
    }
    
    /** Sets the current clipping area.
     *
     * @param c the new clipping area that was copyed.
     */
    public void setClip( Shape c ) {
	__currentClip = c.getBounds2D() ;
	_veSetClip( __currentClip ) ;
    }

    /** Sets the current foreground color.
     *
     * @param c the new color.
     */
    public void setColor( Color c ) {
	__currentColor = c ;
	_veSetColor( __currentColor ) ;
    }

    /** Sets the current font.
     *
     * @param f the new font.
     */
    public void setFont( Font f ) {
	__currentFont = f ;
	_veSetFont( __currentFont ) ;
    }

    /** Sets the paint mode of this graphics context to 
     *  overwrite the destination  with his context's
     *  current color.
     *  <p>
     *  This method is ignored.
     */
    public void setPaintMode() {
    }

    /** Sets the paint mode of this graphics context to 
     *  alternate the destination between this context's
     *  current color and the specified one.
     *  <p>
     *  This method is ignored.
     *
     * @param c the color used to alternate.
     */
    public void setXORMode( Color c ) {
    }

    ////////////////////////////////////////////////////////////
    // Graphics2D API

    /** Sets the values of an arbitrary number of preferences
     *  for the rendering algorithms.
     *
     * @param hints the set of preferences.
     */
    public void addRenderingHints( Map hints ) {
	__renderPrefs.putAll( hints ) ;
    }

    /** Intersects the current clip with the specified rectangle.
     *  <p>
     *  The given coordinates will <em>not</em> be transformed.
     *
     * @param area the clipping area used to intersect.
     */
    public void clip( Shape area ) {
	Rectangle r = area.getBounds() ;
	clipRect( r.x, r.y, 
		  r.width, r.height ) ;
    }

    /** Strokes the outline of a specified shape.
     *
     * @param s the shape to draw.
     */
    public void draw( Shape s ) {
	__drawShape( __affineTransform.createTransformedShape( s ), 
		     __currentColor ) ;
    }

    /** Renders the text of the specified glyph.
     *
     * @param glyph the glyph to display.
     * @param x horizontal location of the text.
     * @param y vertical location of the text.
     */
    public void drawGlyphVector( GlyphVector glyph, float x, float y ) {
// 	for( int i=0; i< glyph.getNumGlyphs(); i++ ) {
// 	    Shape g = glyph.getGlyphOutline( i ) ;
// 	    Point2D location = glyph.getGlyphPosition( i ) ;
// 	    AffineTransform at = new AffineTransform( __affineTransform ) ;
// 	    at.translate( location.getX() + x, location.getY() + y ) ;
// 	    at.concatenate( glyph.getGlyphTransform( i ) ) ;
// 	    __drawShape( at.createTransformedShape( g ), __currentColor ) ;
// 	}
	Shape s = glyph.getOutline() ;
	translate( x, y ) ;
	__drawShape( __affineTransform.createTransformedShape( s ), __currentColor ) ;
	translate( -x, -y ) ;
    }

    /** Draws the specified image.
     *
     * @param img the image to draw.
     * @param op the filter to be applied to the image before rendering.
     * @param x horizontal location of the image.
     * @param y vertical location of the image.
     */
    public void drawImage( BufferedImage img, BufferedImageOp op, int x, int y ) {
	Image filteredImg = op.filter( img, null ) ;
	__drawImage( filteredImg,
		     new AffineTransform( 1, 0, 0, 1, x, y ),
		     null, null ) ;
    }

    /** Draws the given image.
     *
     * @param img the image to draw.
     * @param xform the affine transformation to apply.
     * @param obs the notified observer.
     * @return <code>true</code> if the image was completly rendered.
     */
    public boolean drawImage( Image img, AffineTransform xform, ImageObserver obs ) {
	AffineTransform at = new AffineTransform( __affineTransform ) ;
	at.concatenate( xform ) ;
	return __drawImage( img, at, null, obs ) ;
    }

    /** Renders a RenderableImage.
     *
     * @param img the image to draw.
     * @param xform the affine transformation to apply.
     */
    public void drawRenderableImage( RenderableImage img, AffineTransform xform ) {
	drawRenderedImage( img.createDefaultRendering(), xform ) ;
    }

    /** Renders a RenderedImage.
     *
     * @param img the image to draw.
     * @param xform the affine transformation to apply.
     */
    public void drawRenderedImage( RenderedImage img, AffineTransform xform ) {
	BufferedImage bi = new BufferedImage( img.getColorModel(),
					      img.copyData( null ),
					      true,
					      new Hashtable() ) ;
	AffineTransform at = new AffineTransform( __affineTransform ) ;
	at.concatenate( xform ) ;
	__drawImage( bi, at, null, null ) ;
    }

    /** Draws the given string.
     *
     * @param s the string to draw.
     * @param x horizontal location of the string.
     * @param y vertical location of the string.
     */
    public void drawString( AttributedCharacterIterator s, float x, float y ) {
	char c = s.first() ;
	while ( c != CharacterIterator.DONE ) {
	    int endRun = s.getRunLimit() ;
	    Map attrs = s.getAttributes() ;
	    StringBuffer str = new StringBuffer() ;
	    // Get the text
	    while ( ( c != CharacterIterator.DONE ) &&
		    ( s.getIndex() <= endRun ) ) {
		str.append( c ) ;
		c = s.next() ;
	    }
	    // Get attributes
	    Font font = (Font)attrs.get( TextAttribute.FONT ) ;
	    Paint color = (Paint)attrs.get( TextAttribute.FOREGROUND ) ;
	    if ( font == null ) {
		font = __currentFont ;
	    }
	    if ( ( color == null ) || ( ! ( color instanceof Color ) ) ) {
		color = __currentColor ;
	    }
	    // Computes the location
	    AffineTransform at = new AffineTransform( __affineTransform ) ;
	    Rectangle2D rect = font.getStringBounds( str.toString(), getFontRenderContext() ) ;
	    at.translate( x, y ) ;
	    x += rect.getWidth() ;
	    // Draws the string
	    __drawString( str.toString(), 
			  at, 
			  font, 
			  (Color)color ) ;
	}
    }

    /** Draws the given string.
     *
     * @param s the string to draw.
     * @param x horizontal location of the string.
     * @param y vertical location of the string.
     */
    public void drawString( AttributedCharacterIterator s, int x, int y ) {
	drawString( s, (float)x, (float)y ) ;
    }

    /** Draws the given string.
     *
     * @param s the string to draw.
     * @param x horizontal location of the string.
     * @param y vertical location of the string.
     */
    public void drawString( String s, float x, float y ) {
	AffineTransform at = new AffineTransform( __affineTransform ) ;
	at.translate( x, y ) ;
	__drawString( s, at, __currentFont, __currentColor ) ;
    }

    /** Draws the given string.
     *
     * @param s the string to draw.
     * @param x horizontal location of the string.
     * @param y vertical location of the string.
     */
    public void drawString( String s, int x, int y ) {
	AffineTransform at = new AffineTransform( __affineTransform ) ;
	at.translate( x, y ) ;
	__drawString( s, at, __currentFont, __currentColor ) ;
    }

    /** Fills the interior of a shape.
     *
     * @param s the shape to fill.
     */
    public void fill( Shape s ) {
	__fillShape( __affineTransform.createTransformedShape( s ), 
		     __currentColor ) ;
    }

    /** Replies the current clearing color.
     *
     * @return the current background color.
     */
    public Color getBackground() {
	return __backgroundColor ;
    }

    /** Replies the current composite.
     *
     * @return the current composite.
     */
    public Composite getComposite() {
	return __currentComposite ; 
    }

    /** Replies the device configuration
     *  for this vectorial exporter.
     *
     * @return the description of this device.
     */
    public GraphicsConfiguration getDeviceConfiguration() {
	GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment() ;
	GraphicsDevice[] gds = ge.getScreenDevices() ;
	if ( gds.length > 0 ) {
	    return gds[0].getDefaultConfiguration() ;
	}
	else {
	    return null ;
	}
    }

    /** Replies the current font rendering context.
     *
     * @return the font rendering context.
     */
    public FontRenderContext getFontRenderContext() {
	return new FontRenderContext( __affineTransform, true, true ) ;
    }    

    /** Replies the current Paint.
     *
     * @return the current color.
     */
    public Paint getPaint() {
	return __currentColor ;
    }

    /** Replies the value of an rendering property.
     *
     * @param hintKey a property key.
     * @return the value correspoding to the property
     *         key, or <code>null</code>.
     */
    public Object getRenderingHint( RenderingHints.Key hintKey ) {
	return __renderPrefs.get( hintKey ) ;
    }

    /** Replies all preferences for the rendering algorithms.
     *
     * @return the rendering preferences.
     */
    public RenderingHints getRenderingHints() {
	return __renderPrefs ; 
    }

    /** Replies the current stroke.
     *
     * @return the current painting stroke.
     */
    public Stroke getStroke() {
	return __currentStroke ;
    }

    /** Replies the current affine transformation.
     *
     * @return a affine transformation matrix.
     */
    public AffineTransform getTransform() {
	return new AffineTransform( __affineTransform ) ;
    }

    /** Sets the current affine transformation.
     *  If <var>tx</var> is <code>null</code>,
     *  this method does nothing.
     *
     * @param tx the new affine transformation.
     */
    public void setTransform( AffineTransform tx ) {
	if ( tx == null ) return ;
	__affineTransform = tx ;
    }

    /** Checks whether or not the specified shape intersects
     *  the specified rectangle.
     *  If <var>onStroke</var> is <code>true</code>, the
     *  {@link Stroke Stroke} outline is tested. If the
     *  flag is <code>false</code>, the filled
     *  {@link Shape Shape} is tested.
     *
     * @param rect the rectangle in the vectorial context.
     * @param s the shape to check.
     * @param onStroke flag used to choose between testing
     *                 the stroked or the filled shape.
     * @return <code>true</code> if there is a hit.
     */
    public boolean hit( Rectangle rect, Shape s, boolean onStroke ) {
	Shape shape = __affineTransform.createTransformedShape( rect ) ;
	if ( onStroke ) {
	    Shape ns = __currentStroke.createStrokedShape( s ) ;
	    return ns.intersects( shape.getBounds2D() ) ; 
	}
	else {
	    return s.intersects( shape.getBounds2D() ) ;
	}
    }

    /** Adds a shear into the current
     *  affine transformation.
     *
     * @param shx horizontal multiplier
     * @param shy vertical multiplier
     */
    public void shear( double shx, double shy ) {
	__affineTransform.shear( shx, shy ) ;
    }

    /** Adds a scale into the current
     *  affine transformation.
     *
     * @param scx horizontal scaling
     * @param scy vertical scaling
     */
    public void scale( double scx, double scy ) {
	__affineTransform.scale( scx, scy ) ;
    }

    /** Adds a rotation into the current
     *  affine transformation.
     *
     * @param theta rotation angle
     * @param rx horizontal translation
     * @param ry vertical translation
     */
    public void rotate( double theta, double rx, double ry ) {
	__affineTransform.rotate( theta, rx, ry ) ;
    }

    /** Adds a rotation into the current
     *  affine transformation.
     *
     * @param theta rotation angle
     */
    public void rotate( double theta ) {
	__affineTransform.rotate( theta ) ;
    }

    /** Sets the background color.
     *
     * @param color the new clearing color.
     */
    public void setBackground( Color color ) {
	__backgroundColor = color ;
    }

    /** Sets the current composite.
     *
     * @param c the new composite.
     */
    public void setComposite( Composite c ) {
	__currentComposite = c ;
    }

    /** Sets the current brush.
     *  <p>
     *  If the given parameter is not a
     *  {@link Color solid color}, this
     *  method does nothing.
     *
     * @param brush the new brush.
     */
    public void setPaint( Paint brush ) {
	if ( brush instanceof Color ) {
	    setColor( (Color) brush ) ;
	}
    }

    /** Sets the value of a rendering preference.
     *
     * @param key the name of the preference.
     * @param value the new value of the preference.
     */
    public void setRenderingHint( RenderingHints.Key key, Object value ) {
	__renderPrefs.put( key, value ) ;
    }

    /** Replaces the rendering preferences.
     *
     * @param hints the new preferences.
     */
    public void setRenderingHints( Map hints ) {
	__renderPrefs.putAll( hints ) ;
    }

    /** Replaces the current brush.
     *
     * @param s the new brush.
     */
    public void setStroke( Stroke s ) {
	__currentStroke = s ;
    }

    /** Translates the origin of the graphical context to
     *  the point (<var>x</var>,<var>y</var>) in the
     *  current coordinate system.
     *
     * @param x x coordinate of the new origin.
     * @param y y coordinate of the new origin.
     */
    public void translate( int x, int y ) {
	_veTranslateOrigin( (double)x, (double)y ) ;
    }

    /** Composes an affine transformation with the current
     *  transformation.
     *  If <var>tx</var> is <code>null</code>,
     *  this method does nothing.	
     *
     * @param tx the transformation to add.
     */
    public void transform( AffineTransform tx ) {
	if ( tx == null ) return ;
	__affineTransform.concatenate( tx ) ;
    }

    /** Adds a translation into the current
     *  affine transformation.
     *
     * @param tx horizontal translation.
     * @param ty vertical translation
     */
    public void translate( double tx, double ty ) {
	__affineTransform.translate( tx, ty ) ;
    }

    ////////////////////////////////////////////////////////////
    // Private drawing API

    /** Replies the RGB composent of a color.
     *  This method assure that the returned
     *  integer is between 0x000000 and 0xffffff.
     *
     * @param c the color.
     * @param the RGB composent of <var>c</var>.
     */
    public static int getRGB( Color c ) {
	return ( c.getRGB() & 0xffffff ) ;
    }

    /** Replies the hexadecimal form of an RGB color.
     *
     * @param rgb the RGB definition
     * @return the hexadecimal representation of <var>rgb</var>
     *         (without '#' in the beggining)..
     */
    public static String rgbToHexColor( int rgb ) {
	String red = Integer.toHexString( ( rgb >> 16 ) & 0xff ) ;
	if ( red.length() < 2 ) {
	    red = "0" + red ; 
	}
	String green = Integer.toHexString( ( rgb >> 8 ) & 0xff ) ;
	if ( green.length() < 2 ) {
	    green = "0" + green ; 
	}
	String blue = Integer.toHexString( rgb & 0xff ) ;
	if ( blue.length() < 2 ) {
	    blue = "0" + blue ; 
	}
	return  red + green + blue ;
    }

    /** Replies the hexadecimal form of an RGB color.
     *
     * @param c the color definition
     * @return the hexadecimal representation of <var>rgb</var>
     *         (without '#' in the beggining)..
     */
    public static String rgbToHexColor( Color c ) {
	return rgbToHexColor( getRGB( c ) ) ;
    }

    /** Draws the given image.
     *  We assume that the image can
     *  only be rotating by a multiple
     *  of 90 degrees (pi/2 radians).
     *
     * @param img the image
     * @param tx the affine transformation
     * @param bgColor the color of transparent pixels,
     *                or <code>null</code> if none
     * @param obs the notified observer
     * @return <code>true</code> if theimage was complety drawn.
     */
    private boolean __drawImage( Image img, AffineTransform tx, Color bgColor, ImageObserver obs ) {
	int iw = img.getWidth(obs) ;
	int ih = img.getHeight(obs) ;
	// Computes the transformed picture's bounds
	Rectangle2D transBounds = (tx.createTransformedShape( new Rectangle2D.Float(0f, 0f,
										    iw, ih))).getBounds2D() ;
	// Creates the transformed picture
	int tw = (int)transBounds.getWidth() ;
	int th = (int)transBounds.getHeight() ;
	BufferedImage transformedImg = new BufferedImage( tw, th,
							  BufferedImage.TYPE_INT_ARGB ) ;
	// Generate the transformed picture
	Graphics2D g = (Graphics2D)transformedImg.getGraphics() ;
	g.clipRect( 0, 0, tw, th ) ;
	g.translate( -(int)transBounds.getX(), 
		     -(int)transBounds.getY() ) ;
	g.drawImage( img, tx, obs ) ;
	g.dispose() ;
	// Draws the transformed image
	return  _veDrawImage( transformedImg, 
			      (float)transBounds.getX(), 
			      (float)transBounds.getY(), 
			      (float)tw,
			      (float)th,
			      bgColor, obs ) ;
    }

    /** Draws the given string.
     *
     * @param s the string
     * @param tx the affine transformation
     * @param font the font
     * @param color the color
     */
    private void __drawString( String s, AffineTransform tx, Font font, Color color ) {
	Rectangle2D bounds = font.getStringBounds( s, 
						   getFontRenderContext() ) ;
	Point2D pOrigin = tx.transform( new Point2D.Double( 0f, 0f ), null ) ;
	Point2D pWidth = tx.transform( new Point2D.Double( bounds.getWidth(),
							   0f ), null ) ;
	_veDrawString( s, 
		       (float)pOrigin.getX(),
		       (float)pOrigin.getY(), 
		       (float)Util.getAngleFromVector( pOrigin.getX(),
						       pOrigin.getY(),
						       pWidth.getX(),
						       pWidth.getY() ),
		       font, 
		       font.getSize(),
		       color ) ;
    }

    /** Draws the given shape.
     *
     * @param s the shape to draw.
     * @param c the drawing color.
     */
    private void __drawShape( Shape s, Color c ) {
	if ( s instanceof Rectangle2D ) {
	    _veDrawRect( (Rectangle2D)s, c ) ;
	}
	else if ( s instanceof Polygon ) {
	    _veDrawPolygon( (Polygon)s, c ) ;
	}
	else if ( s instanceof Arc2D ) {
	    _veDrawArc( (Arc2D)s, c ) ;
	}
	else if ( s instanceof Ellipse2D ) {
	    _veDrawOval( (Ellipse2D)s, c ) ;
	}
	else if ( s instanceof RoundRectangle2D ) {
	    _veDrawRoundRect( (RoundRectangle2D)s, c ) ;
	}
	else if ( s instanceof Area ) {
	    __drawPathIterator( ((Area)s).getPathIterator( new AffineTransform() ), c ) ;
	}
	else if ( s instanceof Line2D ) {
	    _veDrawLine( (Line2D)s, c ) ;
	}
	else if ( s instanceof GeneralPath ) {
	    __drawPathIterator( ((GeneralPath)s).getPathIterator( new AffineTransform() ), c ) ;
	}
	else if ( s instanceof QuadCurve2D ) {
	    __drawCurve( (QuadCurve2D)s, c ) ;
	}
	else if ( s instanceof CubicCurve2D ) {
	    __drawCurve( (CubicCurve2D)s, c ) ;
	}
	else {
	    throw new InvalidShapeError( s.getClass() ) ;
	}
    }

    /** Fills the given shape.
     *
     * @param s the shape to fill.
     * @param c the filling color.
     */
    private void __fillShape( Shape s, Color c ) {
	if ( s instanceof Rectangle2D ) {
	    _veFillRect( (Rectangle2D)s, c ) ;
	}
	else if ( s instanceof Polygon ) {
	    _veFillPolygon( (Polygon)s, c ) ;
	}
	else if ( s instanceof Arc2D ) {
	    _veFillArc( (Arc2D)s, c ) ;
	}
	else if ( s instanceof Ellipse2D ) {
	    _veFillOval( (Ellipse2D)s, c ) ;
	}
	else if ( s instanceof RoundRectangle2D ) {
	    _veFillRoundRect( (RoundRectangle2D)s, c ) ;
	}
	else if ( s instanceof Area ) {
	    __fillPathIterator( ((Area)s).getPathIterator( new AffineTransform() ), c ) ;
	}
	else if ( s instanceof Line2D ) {
	    _veDrawLine( (Line2D)s, c ) ;
	}
	else if ( s instanceof GeneralPath ) {
	    __fillPathIterator( ((GeneralPath)s).getPathIterator( new AffineTransform() ), c ) ;
	}
	else if ( s instanceof QuadCurve2D ) {
	    __fillCurve( (QuadCurve2D)s, c ) ;
	}
	else if ( s instanceof CubicCurve2D ) {
	    __fillCurve( (CubicCurve2D)s, c ) ;
	}
	else {
	    throw new InvalidShapeError( s.getClass() ) ;
	}
    }

    /** Draws the given path.
     *
     * @param p the path to draw.
     * @param c the drawing color.
     */
    private void __drawPathIterator( PathIterator s, Color c ) {
	float[] coords = new float[6] ;
	float[] lastMoveTo = null ;
	float[] lastPoint = null ;
	while ( ! s.isDone()  ) {
	    switch( s.currentSegment( coords ) ) {
	    case PathIterator.SEG_MOVETO:
		lastPoint = new float[2] ;
		lastPoint[0] = coords[0] ;
		lastPoint[1] = coords[1] ;
		lastMoveTo = lastPoint ;
		break;
	    case PathIterator.SEG_LINETO:
		if ( lastPoint != null ) {
		    _veDrawLine( new Line2D.Float( lastPoint[0],
						   lastPoint[1],
						   coords[0],
						   coords[1] ),
				 c ) ;
		}
		lastPoint = new float[2] ;
		lastPoint[0] = coords[0] ;
		lastPoint[1] = coords[1] ;
		break;
	    case PathIterator.SEG_QUADTO:
		if ( lastPoint != null ) {
		    __drawCurve( new QuadCurve2D.Float( lastPoint[0],
							lastPoint[1],
							coords[0],
							coords[1],
							coords[2],
							coords[3] ),
				 c ) ;
		}
		lastPoint = new float[2] ;
		lastPoint[0] = coords[2] ;
		lastPoint[1] = coords[3] ;
		break;
	    case PathIterator.SEG_CUBICTO:
		if ( lastPoint != null ) {
		    __drawCurve( new CubicCurve2D.Float( lastPoint[0],
							 lastPoint[1],
							 coords[0],
							  coords[1],
							 coords[2],
							 coords[3],
							 coords[4],
							 coords[5] ),
				 c ) ;
		}
		lastPoint = new float[2] ;
		lastPoint[0] = coords[4] ;
		lastPoint[1] = coords[5] ;
		break;
	    case PathIterator.SEG_CLOSE:
		if ( ( lastPoint != null ) &&
		     ( lastMoveTo != null ) ) {
		    _veDrawLine( new Line2D.Float( lastPoint[0],
						   lastPoint[1],
						   lastMoveTo[0],
						   lastMoveTo[1] ),
				 c ) ;
		}
		lastPoint = new float[2] ;
		lastPoint[0] = lastMoveTo[0] ;
		lastPoint[1] = lastMoveTo[1] ;
		break;
	    }
	    s.next() ;
	}
    }

    /** Fills the given path.
     *
     * @param p the path to draw.
     * @param c the drawing color.
     */
    private void __fillPathIterator( PathIterator s, Color c ) {
	float[] coords = new float[6] ;
	float[] lastMoveTo = null ;
	float[] lastPoint = null ;
	Polygon polygon = null ;
	while ( ! s.isDone()  ) {
	    switch( s.currentSegment( coords ) ) {
	    case PathIterator.SEG_MOVETO:
		if ( polygon != null ) {
		    _veFillPolygon( polygon, c ) ;
		}
		polygon = new Polygon() ;
		lastPoint = new float[2] ;
		lastPoint[0] = coords[0] ;
		lastPoint[1] = coords[1] ;
		lastMoveTo = lastPoint ;
		polygon.addPoint( (int)lastMoveTo[0], (int)lastMoveTo[1] ) ;
		break;
	    case PathIterator.SEG_LINETO:
		if ( lastPoint != null ) {
		    polygon.addPoint( (int)coords[0], (int)coords[1] ) ;
		}
		lastPoint = new float[2] ;
		lastPoint[0] = coords[0] ;
		lastPoint[1] = coords[1] ;
		break;
	    case PathIterator.SEG_QUADTO:
		if ( lastPoint != null ) {
		    QuadCurve2D curve = new QuadCurve2D.Float( lastPoint[0],
							       lastPoint[1],
							       coords[0],
							       coords[1],
							       coords[2],
							       coords[3] ) ;
		    // Approximates the curve
		    __fillPolygonFromPathIterator( polygon,
						   curve.getPathIterator( new AffineTransform(), 
									  __curveApproxRatio ) ) ;
		}
		lastPoint = new float[2] ;
		lastPoint[0] = coords[2] ;
		lastPoint[1] = coords[3] ;
		break;
	    case PathIterator.SEG_CUBICTO:
		if ( lastPoint != null ) {
		    CubicCurve2D curve = new CubicCurve2D.Float( lastPoint[0],
								 lastPoint[1],
								 coords[0],
								 coords[1],
								 coords[2],
								 coords[3],
								 coords[4],
								 coords[5] ) ;
		    // Approximates the curve
		    __fillPolygonFromPathIterator( polygon, 
						   curve.getPathIterator( new AffineTransform(), 
									  __curveApproxRatio ) ) ;
		}
		lastPoint = new float[2] ;
		lastPoint[0] = coords[4] ;
		lastPoint[1] = coords[5] ;
		break;
	    case PathIterator.SEG_CLOSE:
		if ( ( lastPoint != null ) &&
		     ( lastMoveTo != null ) ) {
		    polygon.addPoint( (int)lastMoveTo[0], (int)lastMoveTo[1] ) ;
		}
		lastPoint = new float[2] ;
		lastPoint[0] = lastMoveTo[0] ;
		lastPoint[1] = lastMoveTo[1] ;
		break;
	    }
	    s.next() ;
	}
	if ( polygon != null ) {
	    _veFillPolygon( polygon, c ) ;
	}
    }

    /** Updates the specified polygon with the
     *  given path iterator
     *
     * @param polygon the polygon to updates
     * @param path the points to add into the polygon
     */
    private void __fillPolygonFromPathIterator( Polygon polygon, PathIterator path ) {
	float[] coords = new float[6] ;
	float[] lastMoveTo = null ;
	float[] lastPoint = null ;
	while ( ! path.isDone()  ) {
	    switch( path.currentSegment( coords ) ) {
	    case PathIterator.SEG_MOVETO:
		lastPoint = new float[2] ;
		lastPoint[0] = coords[0] ;
		lastPoint[1] = coords[1] ;
		lastMoveTo = lastPoint ;
		polygon.addPoint( (int)lastMoveTo[0], (int)lastMoveTo[1] ) ;
		break;
	    case PathIterator.SEG_LINETO:
		if ( lastPoint != null ) {
		    polygon.addPoint( (int)coords[0], (int)coords[1] ) ;
		}
		lastPoint = new float[2] ;
		lastPoint[0] = coords[0] ;
		lastPoint[1] = coords[1] ;
		break;
	    case PathIterator.SEG_CLOSE:
		if ( ( lastPoint != null ) &&
		     ( lastMoveTo != null ) ) {
		    polygon.addPoint( (int)lastMoveTo[0], (int)lastMoveTo[1] ) ;
		}
		lastPoint = new float[2] ;
		lastPoint[0] = lastMoveTo[0] ;
		lastPoint[1] = lastMoveTo[1] ;
		break;
	    }
	    path.next() ;
	}
    }

    /** Draws a quadratic curve.
     *
     * @param curve the curve to draw.
     * @param c the drawing color.
     */
    private void __drawCurve( QuadCurve2D curve, Color c ) {
	if ( __approxCurves ) {
	    __drawPathIterator( curve.getPathIterator( new AffineTransform(), 
						       __curveApproxRatio ),
				c ) ;
	}
	else {
	    _veDrawCurve( curve, c ) ;
	}
    }

    /** Draws a cubic curve.
     *
     * @param curve the curve to draw.
     * @param c the drawing color.
     */
    private void __drawCurve( CubicCurve2D curve, Color c ) {
	if ( __approxCurves ) {
	    __drawPathIterator( curve.getPathIterator( new AffineTransform(), 
						       __curveApproxRatio ),
				c ) ;
	}
	else {
	    _veDrawCurve( curve, c ) ;
	}
    }

    /** Fills a quadratic curve.
     *
     * @param curve the curve to draw.
     * @param c the drawing color.
     */
    private void __fillCurve( QuadCurve2D curve, Color c ) {
	if ( __approxCurves ) {
	    __fillPathIterator( curve.getPathIterator( new AffineTransform(), 
						       __curveApproxRatio ),
				c ) ;
	}
	else {
	    _veFillCurve( curve, c ) ;
	}
    }

    /** Fills a cubic curve.
     *
     * @param curve the curve to draw.
     * @param c the drawing color.
     */
    private void __fillCurve( CubicCurve2D curve, Color c ) {
	if ( __approxCurves ) {
	    __fillPathIterator( curve.getPathIterator( new AffineTransform(), 
						       __curveApproxRatio ),
				c ) ;
	}
	else {
	    _veFillCurve( curve, c ) ;
	}
    }

    ////////////////////////////////////////////////////////////
    // Overridable API

    /** Draws the given line.
     *
     * @param l the line to draw.
     * @param c the drawing color.
     */
    protected abstract void _veDrawLine( Line2D l, Color c ) ;

    /** Draws the given rectangle.
     *
     * @param r the rectangle to draw.
     * @param c the drawing color.
     */
    protected abstract void _veDrawRect( Rectangle2D r, Color c ) ;

    /** Fills the given rectangle.
     *
     * @param r the rectangle to fill.
     * @param c the filling color.
     */
    protected abstract void _veFillRect( Rectangle2D r, Color c ) ;

    /** Draws the given oval.
     *
     * @param o the ellipse to draw.
     * @param c the drawing color.
     */
    protected abstract void _veDrawOval( Ellipse2D o, Color c ) ;

    /** Fills the given oval.
     *
     * @param o the ellipse to fill.
     * @param c the filling color.
     */
    protected abstract void _veFillOval( Ellipse2D o, Color c ) ;

    /** Draws the given rectangle.
     *
     * @param r the rectangle to draw.
     * @param c the drawing color.
     */
    protected abstract void _veDrawRoundRect( RoundRectangle2D r, Color c ) ;

    /** Fills the given rectangle.
     *
     * @param r the rectangle to fill.
     * @param c the filling color.
     */
    protected abstract void _veFillRoundRect( RoundRectangle2D r, Color c ) ;

    /** Draws the given polygon.
     *
     * @param p the polygon to draw.
     * @param c the drawing color.
     */
    protected abstract void _veDrawPolygon( Polygon p, Color c ) ;

    /** Fills the given polygon.
     *
     * @param p the polygon to draw.
     * @param c the drawing color.
     */
    protected abstract void _veFillPolygon( Polygon p, Color c ) ;

    /** Draws the given arc.
     *
     * @param r the arc to draw.
     * @param c the drawing color.
     */
    protected abstract void _veDrawArc( Arc2D r, Color c ) ;

    /** Fills the given arc.
     *
     * @param r the arc to fill.
     * @param c the filling color.
     */
    protected abstract void _veFillArc( Arc2D r, Color c ) ;

    /** Draws the given curve.
     *
     * @param qc a quadratic curve.
     * @param c the drawing color.
     */
    protected void _veDrawCurve( QuadCurve2D qc, Color c ) {
	throw new OverwriteThisMethodError() ;
    }

    /** Draws the given curve.
     *
     * @param cc a cubic curve.
     * @param c the drawing color.
     */
    protected void _veDrawCurve( CubicCurve2D cc, Color c ) {
	throw new OverwriteThisMethodError() ;
    }

    /** Fills the given curve.
     *
     * @param qc a quadratic curve.
     * @param c the drawing color.
     */
    protected void _veFillCurve( QuadCurve2D qc, Color c ) {
	throw new OverwriteThisMethodError() ;
    }

    /** Fills the given curve.
     *
     * @param cc a cubic curve.
     * @param c the drawing color.
     */
    protected void _veFillCurve( CubicCurve2D cc, Color c ) {
	throw new OverwriteThisMethodError() ;
    }

    /** Draws the given string.
     *
     * @param s the text to draw.
     * @param x horizontal position.
     * @param y vertical position.
     * @param angle is the rotation angle of the string
     * @param font the font used.
     * @param fontSize the desired size of the font.
     * @param color the rendering color.
     */
    protected abstract void _veDrawString( String s, float x, float y, 
					   float angle,
					   Font font, int fontSize,
					   Color color ) ;

    /** Draws the given image.
     *
     * @param img the image
     * @param x horizontal position.
     * @param y vertical position.
     * @param width the desired width of the picture.
     * @param height the desired height of the picture.
     * @param bgColor the color of transparent pixels,
     *                or <code>null</code> if none
     * @param obs the notified observer
     * @return <code>true</code> if theimage was complety drawn.
     */
    protected abstract boolean _veDrawImage( Image img, 
					     float x, float y, 
					     float width, float height,
					     Color bgColor, ImageObserver obs ) ;

    /** Translates the origin of the graphical context to
     *  the point (<var>x</var>,<var>y</var>) in the
     *  current coordinate system.
     *
     * @param x x coordinate of the new origin.
     * @param y y coordinate of the new origin.
     */
    protected abstract void _veTranslateOrigin( double x, double y ) ;

    /** Sets the clipping area.
     *
     * @param area the new clipping area, or <code>null</code>
     *             if no clipping was needed.
     */
    protected abstract void _veSetClip( Rectangle2D area ) ;

    /** Sets the current foreground color.
     *
     * @param color the new color, which is used to draw.
     */
    protected abstract void _veSetColor( Color color ) ;

    /** Sets the current font.
     *
     * @param font the new font, which is used to draw.
     */
    protected abstract void _veSetFont( Font font ) ;

}

///////////////////////////////////////////
// XEmacs macros
//
// Local Variables: 
// compile-command: "make -k classesall"
// End: 
