//   Copyright (C) 2002  St�phane Galland, Mahdi Hannoun
//
//   This library is free software; you can redistribute it and/or
//   modify it under the terms of the GNU Lesser General Public
//   License as published by the Free Software Foundation; either
//   version 2.1 of the License, or (at your option) any later version.
//
//   This library is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//   Lesser General Public License for more details.

//   You should have received a copy of the GNU Lesser General Public
//   License along with this library; if not, write to the Free Software
//   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//   This program is free software; you can redistribute it and/or modify

package org.arakhne.neteditor.io ;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.ImageObserver;
import java.awt.image.PixelGrabber;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Date;

import org.arakhne.neteditor.throwable.export.ExporterError;
import org.arakhne.util.ExtensionFileFilter;

/** This graphic context permits to create a Postscript file
 *  from a graphic context.
 *  <p>
 *  More informations about Postscript format are in
 *  <a href="http://www.adobe.com/products/postscript/main.html">http://www.adobe.com/products/postscript/main.html</a>.
 *  <p><center>
 *    <img src="doc-files/PostscriptWriter_uml.png" border="0">
 *  </center>
 *
 * \beginLog
 * \revision 02/03/12 0.3 St�phane Adds the default constructor,
 *                        and implements some abstract methods
 *                        inherited for VectorialExporter.
 * \revision 02/02/18 0.2 St�phane Fixes bugs about bitmap
 *             font generation
 * \revision 02/01/29 0.1 St�phane Initial release
 * \endLog
 *
 * @author St�phane Galland
 * @version 0.3, 02/03/12
 */
public class PostscriptWriter extends VectorialExporter {

    ////////////////////////////////////////////////////////////
    /// Attributes

    /** Width of the page.
     *  <p>
     *  By default, it sets to the Letter format.
     *
     * @since 0.3
     */
    public static final int PAGE_WIDTH = 535 ;

    /** Height of the page.
     *  <p>
     *  By default, it sets to the Letter format.
     *
     * @since 0.3
     */
    public static final int PAGE_HEIGHT = 778 ;

    /** This is the output stream used to generate the
     *  Postscript file.
     */
    private PrintWriter __os = null;

    /** This is the bouding box given during the creation of
     *  this object.
     *  <p>
     *  By default, it sets to the Letter format.
     */
    private Rectangle __boundingBox = new Rectangle(0, 0, 
						    PAGE_WIDTH, 
						    PAGE_HEIGHT) ;

    /** This is the bouding box given by the user of
     *  this exporter.
     */
    private Rectangle __drawingArea = null ;

    /** Indicates if this document is an Encapsuled Postscript.
     */
    private boolean __isEPS = false ;

    /** This attribute is used to store temporally the
     *  initial scaling factor
     *
     * @since 0.3
     */
    private double __initialScale = 1.0 ;

    ////////////////////////////////////////////////////////////
    // Constructor

    /** Construct a new PostscriptWriter.
     *
     * @param writer the PostscriptWriter to copy.
     */
    protected PostscriptWriter( PostscriptWriter writer ) {
	this( writer, writer.__os ) ;
    }

    /** Construct a new PostscriptWriter.
     *
     * @param writer the PostscriptWriter to copy.
     * @param stream the new output stream
     */
    protected PostscriptWriter( PostscriptWriter writer, PrintWriter stream ) {
	// Saves the bouding box
	__boundingBox = writer.__boundingBox ;
	__isEPS = writer.__isEPS ;
	// Sets the output stream
	__os = stream ;
	// begin to generate
	exportProlog() ;
    }

    /** Construct a new PostscriptWriter.
     */
    public PostscriptWriter()
	throws IOException {
    }

    ////////////////////////////////////////////////////////////
    // Overridable API

    /** Sets the drawing area used to export the document.
     *  See subclasses for more details about the use of
     *  the drawing area.
     *
     * @param r is the drawing area in which the document must
     *          be exported.
     * @since 0.3
     */
    public void setDrawingArea( Rectangle r ) {
	__drawingArea = r ;
	if ( __isEPS ) {
	    __boundingBox = r ;
	}
	else {
	    __boundingBox = new Rectangle( 0, 0,
					   PAGE_WIDTH,
					   PAGE_HEIGHT ) ;
	    __initialScale = Math.min( (double)PAGE_WIDTH / __drawingArea.width,
				       (double)PAGE_HEIGHT / __drawingArea.height ) ;
	}
    }

    /** Sets the target file. See subclasses for more
     *  details about the use of the target filename.
     *
     * @param os is the output stream.
     * @param f the name of the target file.
     * @since 0.3
     */
    public void setTargetFile( OutputStream os, File f ) {
	__os = new PrintWriter( os ) ;
	String ext  = ExtensionFileFilter.getExtension( f ) ;
	__isEPS = ( "eps".equals( ext ) ) ;
    }

    /** Exports the prolog for this document.
     * 
     * @since 0.3
     */
    public void exportProlog() {
	// Generates the prolog
	generateProlog( __boundingBox ) ;
	// Generate the Postscript setup
	generateSetup() ;
	// Be sure that coordinates are in the given bouding box
	translate( 0, 
		   __boundingBox.height + 2 * __boundingBox.y );
	// Print the beggining of the document
	generateDocumentBegin() ;
	// Do transformations depending of the type of generated document
	if ( ! __isEPS ) {
	    //translate( -__drawingArea.x, -__drawingArea.y ) ;
	    if (__initialScale < 1.0) {
		scale( __initialScale, __initialScale ) ;
	    }
	}
    }

    /** Creates a new instance this graphics context that
     *  is a copy of this object.
     *
     * @return a copy of this PostscriptWriter.
     */
    public Graphics create() {
	return new PostscriptWriter( this ) ;
    }

    /** Creates a new instance this graphics context that
     *  is a copy of this object.
     *
     * @param stream the target stream
     * @return a copy of this PostscriptWriter.
     */
    public Graphics create( OutputStream stream ) {
	return new PostscriptWriter( this, new PrintWriter( stream ) ) ;
    }

    /** Disposes this graphics context.
     */
    public void dispose() {
	generateDocumentEnd() ;
      	__os.println("showpage") ;
	__os.println("%%Trailer") ;
	// Close the stream
	__os.close() ;
    }

    /** Draws the given line.
     *
     * @param l the line to draw.
     * @param c the drawing color.
     */
    protected void _veDrawLine( Line2D l, Color c ) {
	generateComment( "begin: _veDrawLine" ) ;
	__os.println( "newpath" ) ;
	generateCoords( (float)l.getX1(), (float)l.getY1() ) ; 
	__os.println( "moveto" ) ;
	generateCoords( (float)l.getX2(), (float)l.getY2() ) ; 
	__os.println( "lineto" ) ;
	__os.println( "stroke" ) ;	
	generateComment( "end: _veDrawLine" ) ;
    }

    /** Draws the given rectangle.
     *
     * @param r the rectangle to draw.
     * @param c the drawing color.
     */
    protected void _veDrawRect( Rectangle2D r, Color c ) {
	generateComment( "begin: _veDrawRect" ) ;
	generateRect( (float)r.getX(), 
		      (float)r.getY(), 
		      (float)r.getWidth() + 1, 
		      (float)r.getHeight() + 1 );
	__os.println( "stroke" );
	generateComment( "end: _veDrawRect" ) ;
    }

    /** Fills the given rectangle.
     *
     * @param r the rectangle to fill.
     * @param c the filling color.
     */
    protected void _veFillRect( Rectangle2D r, Color c )  {
	generateComment( "begin: _veFillRect" ) ;
	generateRect( (float)r.getX(), 
		      (float)r.getY(), 
		      (float)r.getWidth() + 1, 
		      (float)r.getHeight() + 1 );
	__os.println( "eofill" );
	generateComment( "end: _veFillRect" ) ;
    }

    /** Draws the given oval.
     *
     * @param o the ellipse to draw.
     * @param c the drawing color.
     */
    protected void _veDrawOval( Ellipse2D o, Color c ) {
	generateComment( "begin: _veDrawOval" ) ;
	generateEllipse( (float)o.getX(), 
			 (float)o.getY(),
			 (float)o.getWidth() + 1, 
			 (float)o.getHeight() + 1, 
			 0f, 360f ) ;
	__os.println( "stroke" ) ;
	generateComment( "end: _veDrawOval" ) ;
    }

    /** Fills the given oval.
     *
     * @param o the ellipse to fill.
     * @param c the filling color.
     */
    protected void _veFillOval( Ellipse2D o, Color c ) {
	generateComment( "begin: _veFillOval" ) ;
	generateEllipse( (float)o.getX(), 
			 (float)o.getY(),
			 (float)o.getWidth() + 1, 
			 (float)o.getHeight() + 1, 
			 0f, 360f ) ;
	__os.println( "oefill" ) ;
	generateComment( "end: _veFillOval" ) ;
    }

    /** Draws the given rectangle.
     *
     * @param r the rectangle to draw.
     * @param c the drawing color.
     */
    protected void _veDrawRoundRect( RoundRectangle2D r, Color c ) {
	generateComment( "begin: _veDrawRoundRect" ) ;
	generateRoundRect( (float)r.getX(), 
			   (float)r.getY(), 
			   (float)r.getWidth() + 1, 
			   (float)r.getHeight() + 1,
			   (float)r.getArcWidth(),
			   (float)r.getArcHeight() ) ;
	__os.println( "stroke" ) ;
	generateComment( "end: _veDrawRoundRect" ) ;
    }

    /** Fills the given rectangle.
     *
     * @param r the rectangle to fill.
     * @param c the filling color.
     */
    protected void _veFillRoundRect( RoundRectangle2D r, Color c ) {
	generateComment( "begin: _veFillRoundRect" ) ;
	generateRoundRect( (float)r.getX(), 
			   (float)r.getY(), 
			   (float)r.getWidth() + 1, 
			   (float)r.getHeight() + 1,
			   (float)r.getArcWidth(),
			   (float)r.getArcHeight() ) ;
	__os.println( "eofill" ) ;
	generateComment( "end: _veFillRoundRect" ) ;
    }

    /** Draws the given polygon.
     *
     * @param p the polygon to draw.
     * @param c the drawing color.
     */
    protected void _veDrawPolygon( Polygon p, Color c ) {
	generateComment( "begin: _veDrawPolygon" ) ;
	generatePolygon( p.xpoints, p.ypoints, p.npoints ) ;
	__os.println( "stroke" ) ;
	generateComment( "end: _veDrawPolygon" ) ;
    }

    /** Fills the given polygon.
     *
     * @param p the polygon to draw.
     * @param c the drawing color.
     */
    protected void _veFillPolygon( Polygon p, Color c )  {
	generateComment( "begin: _veFillPolygon" ) ;
	generatePolygon( p.xpoints, p.ypoints, p.npoints ) ;
	__os.println( "eofill" ) ;
	generateComment( "end: _veFillPolygon" ) ;
    }

    /** Draws the given arc.
     *
     * @param a the arc to draw.
     * @param c the drawing color.
     */
    protected void _veDrawArc( Arc2D a, Color c ) {
	generateComment( "begin: _veDrawArc" ) ;
	generateEllipse( (float)a.getX(), 
			 (float)a.getY(), 
			 (float)a.getWidth() + 1, 
			 (float)a.getHeight() + 1, 
			 (float)a.getAngleStart(), 
			 (float)a.getAngleExtent() ) ;
	__os.println( "stroke" ) ;
	generateComment( "end: _veDrawArc" ) ;
    }

    /** Fills the given arc.
     *
     * @param a the arc to fill.
     * @param c the filling color.
     */
    protected void _veFillArc( Arc2D a, Color c )  {
	generateComment( "begin: _veFillArc" ) ;
	generateEllipse( (float)a.getX(), 
			 (float)a.getY(), 
			 (float)a.getWidth() + 1, 
			 (float)a.getHeight() + 1, 
			 (float)a.getAngleStart(), 
			 (float)a.getAngleExtent() ) ;
	__os.println( "eofill" ) ;
	generateComment( "end: _veFillArc" ) ;
    }

    /** Draws the given string.
     *
     * @param s the text to draw.
     * @param x horizontal position.
     * @param y vertical position.
     * @param angle is the rotation angle of the string
     * @param font the font used.
     * @param fontSize the desired size of the font.
     * @param color the rendering color.
     */
    protected void _veDrawString( String s, float x, float y, 
				  float angle,
				  Font font, int fontSize,
				  Color color ) {
	generateComment( "begin: _veDrawString" ) ;
	// Translates the string into a PS-compliant string.
	StringBuffer buf = new StringBuffer( s );
	int c;
	String code;
	for (int i = 0; i < buf.length(); ++i) {
	    c = (int)buf.charAt(i);
	    if (c >= 192 && c < 256) {
		buf.setCharAt(i,'\\');
		code = Integer.toOctalString(c);
		buf.insert(i+1,code);
		i += code.length();
	    } else if (c == '\\' || c == '(' || c == ')') {
		buf.insert(i++,'\\');
	    }
	}
	// Display the string
	generateCoords( x, y ) ; 
	__os.println( "moveto" ) ;
	__os.println( "(" + buf.toString() + ") show" ) ;
	generateComment( "end: _veDrawString" ) ;
    }

    /** Draws the given image.
     *
     * @param img the image
     * @param x horizontal position.
     * @param y vertical position.
     * @param width the desired width of the picture.
     * @param height the desired height of the picture.
     * @param bgColor the color of transparent pixels,
     *                or <code>null</code> if none
     * @param obs the notified observer
     * @return <code>true</code> if theimage was complety drawn.
     */
    protected boolean _veDrawImage( Image img, 
				    float x, float y, 
				    float width, float height,
				    Color bgColor, ImageObserver obs ) {
	generateComment( "begin: _veDrawImage" ) ;
	int iw = img.getWidth(obs) ;
	int ih = img.getHeight(obs) ;

	// Set the location and the real size of the image.
        __os.println("gsave") ;
	__os.println( "/DatenString " + iw + " string def" ) ;
        generateCoords((int)x, (int)(y + height)) ; 
	__os.println( "translate" ) ;
	generateCoords((int)width, (int)-height) ; 
	__os.println( "scale" ) ;

	// Generates the original image specification (size...)
	generateCoords(iw, -ih); 
	__os.println( "4 [" + iw +" 0 0 " + (-ih) + " 0 " + ih + "]" ) ;
	__os.println( "{currentfile DatenString readhexstring pop} bind" );
	__os.println( "false 3 colorimage" );

	// Get the pixels of the image
        int[] pixels = new int[iw * ih];
        PixelGrabber pg = new PixelGrabber(img, 0, 0, iw, ih, pixels, 0, iw);
        try {
            pg.grabPixels();
        } 
	catch (InterruptedException e) {
            throw new ExporterError( "waiting for pixels during Postscript generate" );
        }
        
	if ((pg.getStatus() & ImageObserver.ABORT) != 0) {
	    throw new ExporterError( "image fetch aborted or errored" );
        }
	
	// Writes each pixels
        for (int j = 0; j < ih; j++) {
            for (int i = 0; i < iw; i++) {
                generatePixel( i, j, pixels[j * iw + i], bgColor );
            }
        }
	__os.println() ;
	__os.println("grestore");
	generateComment( "end: _veDrawImage" ) ;

        return true;
    }

    /** Translates the origin of the graphical context to
     *  the point (<var>x</var>,<var>y</var>) in the
     *  current coordinate system.
     *
     * @param x x coordinate of the new origin.
     * @param y y coordinate of the new origin.
     */
    protected void _veTranslateOrigin( double x, double y ) {
	generateComment( "begin: _veTranslateOrigin" ) ;
	generateCoords( (float)x, (float)-y ) ;
	__os.println( "translate" ) ;
	generateComment( "end: _veTranslateOrigin" ) ;
    }

    /** Sets the clipping area.
     *
     * @param area the new clipping area, or <code>null</code>
     *             if no clipping was needed.
     */
    protected void _veSetClip( Rectangle2D area ) {
	generateComment( "begin: _veSetClip" ) ;
	generateRect( (float)area.getX(),
		      (float)area.getY(),
		      (float)area.getWidth(), 
		      (float)area.getHeight() );
	__os.println( "clip" );
	generateComment( "end: _veSetClip" ) ;
    }

    /** Sets the current foreground color.
     *
     * @param color the new color, which is used to draw.
     */
    protected void _veSetColor( Color color ) {
	generateComment( "begin: _veSetColor" ) ;
	__os.print( ((float)color.getRed()) / 255 + " " ) ;
	__os.print( ((float)color.getGreen()) / 255 + " " ) ;
	__os.print( ((float)color.getBlue()) / 255 + " " ) ;
	__os.println( "setrgbcolor" ) ;
	generateComment( "end: _veSetColor" ) ;
    }

    /** Sets the current font.
     *
     * @param font the new font, which is used to draw.
     */
    protected void _veSetFont( Font font ) {
	generateComment( "begin: _veSetFont" ) ;
	String name = font.getName();

	// Be sure that the "video" font corresponds
	// to a "Postscript" font
	name = font.getPSName() ;

	// Adds the tags for bold and italic fonts
	if (font.isBold()) {
	    name += "-Bold";
	}
	if (font.isItalic()) {
	    name += "-Oblique";
	}
	
	// Generate the PS font commands
	__os.println( "isolatin1encoding /_" + name + " /" + name + " RE" ) ;
	__os.println( "/_" + name + " findfont" ) ;
	__os.println( font.getSize() + " scalefont setfont" ) ;
	generateComment( "end: _veSetFont" ) ;
    }

    ////////////////////////////////////////////////////////////
    // Postscript API

    /** Generates the Postscript Prolog section.
     *
     * @param boundingbox the bouding box..
     */
    protected void generateProlog( Rectangle boundingbox ) {
	// Generates the Poscript header
	if ( ! __isEPS ) {
	    __os.println( "%!PS-Adobe-3.0" );
	} 
	else {
	    __os.println( "%!PS-Adobe-3.0 EPSF-3.0" );
	}

	__os.println( "%%Creator: Arakhn� NetEditor PostscriptWriter.class" ) ;
	__os.println( "%%CreationDate: " + new Date() ) ;

	if ( ! __isEPS ) {
	    if ( boundingbox.getWidth() <= boundingbox.getHeight() ) {
		__os.println( "%%Orientation: Portrait" ) ;
	    }
	    else {
		__os.println( "%%Orientation: Landscape" ) ;
	    }
	    __os.println( "%%Pages: 1" ) ;
	}
	__os.println( "%%BoundingBox: " +
		      boundingbox.x + " " +
		      boundingbox.y + " " +
		      (boundingbox.x + boundingbox.width) + " " +
		      (boundingbox.y + boundingbox.height) );
	
	__os.print( "%%BeginProcSet: reencode 1.0 0 \n" +
		  "/RE \n" +
		  "{  findfont begin \n" +
		  "  currentdict dup length dict begin \n" +
		  "  {1 index /FID ne {def} {pop pop} ifelse} forall \n" +
		  "  /FontName exch def dup length 0 ne \n" +
		  "  { /Encoding Encoding 256 array copy def \n" +
		  "      0 exch \n" +
		  "      { dup type /nametype eq \n" +
		  "        { Encoding 2 index 2 index put \n" +
		  "          pop 1 add \n" +
		  "        } \n" +
		  "        { exch pop \n" +
		  "        } ifelse \n" +
		  "      } forall \n" +
		  "  } if pop \n" +
		  "  currentdict dup end end \n" +
		  "  /FontName get exch definefont pop \n" +
		  "    } bind def \n" +
		  "%%EndProcSet: reencode 1.0 0 \n" ) ;

	__os.print( "%%BeginProcSet: ellipse 1.0 0 \n" +
		  "/ellipsedict 8 dict def \n" +
		  "ellipsedict /mtrx matrix put \n" +
		  "/ellipse { ellipsedict begin \n" +
		  "/endangle exch def \n" +
		  "/startangle exch def \n"  +
		  "/yrad exch def \n" +
		  "/xrad exch def \n" +
		  "/y exch def \n" +
		  "/x exch def \n" +
		  "/savematrix mtrx currentmatrix def \n" +
		  "x y translate \n" +
		  "xrad yrad scale \n" +
		  "0 0 1 0 360 arc \n" +
		  "savematrix setmatrix end } def \n" +
		  "%%EndProcSet: ellipse 1.0 0 \n" ) ;

	__os.println("%%EndProlog");
    }

    /** Generates the Postscript setup.
     */
    protected void generateSetup() {
	__os.println("%%BeginSetup");
	// ISO Latin 1 encoding
	__os.print( "/isolatin1encoding \n" +
		  "[ 32 /space /exclam /quotedbl /numbersign /dollar /percent /ampersand /quoteright \n" +
		  " /parenleft /parenright /asterisk /plus /comma /hyphen /period /slash /zero /one \n" +
		  " /two /three /four /five /six /seven /eight /nine /colon /semicolon \n" +
		  " /less /equal /greater /question /at /A /B /C /D /E \n" +
		  " /F /G /H /I /J /K /L /M /N /O \n" +
		  " /P /Q /R /S /T /U /V /W /X /Y \n" +
		  " /Z /bracketleft /backslash /bracketright /asciicircum /underscore /quoteleft /a /b /c \n" +
		  " /d /e /f /g /h /i /j /k /l /m \n" +
		  " /n /o /p /q /r /s /t /u /v /w \n" +
		  " /x /y /z /braceleft /bar /braceright /asciitilde /.notdef /.notdef /.notdef \n" +
		  " /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef \n" +
		  " /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef \n" +
		  " /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef \n" +
		  " /space /exclamdown /cent /sterling /currency /yen /brokenbar /section /dieresis /copyright \n" +
		  " /ordfeminine /guillemotleft /logicalnot /hyphen /registered /macron /degree /plusminus /twosuperior /threesuperior \n" +
		  " /acute /mu /paragraph /periodcentered /cedilla /onesuperior /ordmasculine /guillemotright /onequarter /onehalf \n" +
		  " /threequarters /questiondown /Agrave /Aacute /Acircumflex /Atilde /Adieresis /Aring /AE /Ccedilla \n" +
		  " /Egrave /Eacute /Ecircumflex /Edieresis /Igrave /Iacute /Icircumflex /Idieresis /Eth /Ntilde \n" +
		  " /Ograve /Oacute /Ocircumflex /Otilde /Odieresis /multiply /Oslash /Ugrave /Uacute /Ucircumflex \n" +
		  " /Udieresis /Yacute /Thorn /germandbls /agrave /aacute /acircumflex /atilde /adieresis /aring \n" +
		  " /ae /ccedilla /egrave /eacute /ecircumflex /edieresis /igrave /iacute /icircumflex /idieresis \n" +
		  " /eth /ntilde /ograve /oacute /ocircumflex /otilde /odieresis /divide /oslash /ugrave \n" +
		  " /uacute /ucircumflex /udieresis /yacute /thorn /ydieresis] def \n" ) ;
	__os.println("%%EndSetup");
	__os.println("1 setlinewidth");
	// Sets the default graphic status
	setFont(new Font("Helvetica",Font.PLAIN,12));
	setColor(Color.black);
    }

    /** Generates the beggining of the document.
     */
    protected void generateDocumentBegin() {
	if ( ! __isEPS ) {
	    __os.println("%%Page: 1 1" ) ;
	}
    }

    /** Generates the ending of the document.
     */
    protected void generateDocumentEnd() {
    }

    /** Generates a comment.
     *
     * @param cmt the comment to put in the PS file.
     */
    public void generateComment( String cmt ) {
	__os.println("% " + cmt);
    }

    /** Generates two coordinates into the Postscript target.
     *
     * @param x horizontal location.
     * @param y vertical location.
     */
    protected void generateCoords( float x, float y ) {
	__os.print( x + " " + (-y) + " " ) ;
    }

    /** Generates two coordinates into the Postscript target.
     *
     * @param x horizontal location.
     * @param y vertical location.
     */
    protected void generateCoords( int x, int y ) {
	__os.print( x + " " + (-y) + " " ) ;
    }

    /** Generates a pixel.
     *
     * @param x x coordinate of the pixel.
     * @param y y coordinate of the pixel.
     * @param p the pixel to write (RGB code).
     * @param bgColor the color of transparents pixels.
     */
    protected void generatePixel( float x, float y, int p, Color bgColor ) {
	if (((p >> 24) & 0xff) == 0) {
	    // should be transparent:
	    if ( bgColor != null ) {
		p = bgColor.getRGB() ;
	    }
	    else {
		// Default background color is white
		p = 0xffffff;
	    }
        }
        __os.print( Integer.toHexString((p >> 20) & 0x0f) +
		    Integer.toHexString((p >> 12) & 0x0f) +
		    Integer.toHexString((p >> 4)  & 0x0f) );
    }

    /** Generates a rectangle into the Postscript target.
     *
     * @param x x coordinate of the rectangle.
     * @param y y coordinate of the rectangle.
     * @param w width of the rectangle.
     * @param h height of the rectangle.
     */
    protected void generateRect( float x, float y, float w, float h ) {
	__os.println( "newpath" ) ;
	generateCoords( x, y ) ; 
	__os.println( "moveto" ) ;
	generateCoords( w - 1, 0 ) ; 
	__os.println( "rlineto" ) ;
	generateCoords( 0, h - 1 ) ; 
	__os.println( "rlineto" ) ;
	generateCoords( -( w - 1 ), 0 ) ; 
	__os.println( "rlineto" ) ;
	__os.println( "closepath" ) ;
    }

    /** Generates an ellipse into the Postscript target.
     *
     * @param x x coordinate of the ellipse.
     * @param y y coordinate of the ellipse.
     * @param w width of the ellipse.
     * @param h height of the ellipse.
     * @param startAngle starting angle.
     * @param arcAngle the angle of the ellipse.
     */
    protected void generateEllipse( float x, float y, float w, float h, float startAngle, float arcAngle) {
	__os.println( "newpath" );
        float dx = w/2 ;
	float dy = h/2 ;
	generateCoords( x + dx, y + dy );
	generateCoords( dx, dy );
	generateCoords( startAngle, -(startAngle + arcAngle) );
        __os.println( "ellipse" );
    }

    /** Generates a rounded rectangle into the Postscript target.
     *
     * @param x x coordinate of the rounded rectangle.
     * @param y y coordinate of the rounded rectangle.
     * @param w width of the rounded rectangle.
     * @param h height of the rounded rectangle.
     * @param arcw the horizontal diameter of the arc at the four corners.
     * @param arch the vertical diameter of the arc at the four corners.
     */
    protected void generateRoundRect(float x, float y, float w, float h, float arcw, float arch ) {
	String curve = (Math.min( arcw, arch )) + " arcto 4 {pop} repeat" ;
	__os.println("newpath") ;
	generateCoords( x, y + arch ) ; 
	__os.println( "moveto" ) ;
	generateCoords( x, y) ; 
	generateCoords( x + arcw, y ) ; 
	__os.println( curve ) ;
	generateCoords( x + w, y ) ; 
	generateCoords( x + w, y + arch ) ; 
	__os.println( curve ) ;
	generateCoords( x + w, y + h ) ; 
	generateCoords( x + w  - arcw, y +  h ) ; 
	__os.println( curve ) ;
	generateCoords( x, y + h ) ; 
	generateCoords( x, y + h  - arch ) ; 
	__os.println( curve ) ;
	__os.println( "closepath" ) ;
    }

    /** Generates polygone path into the Postscript target.
     *
     * @param xPoints x coordinates of the polygone's points.
     * @param yPoints y coordinates of the polygone's points.
     * @param nPoints the number of points to write.
     */
    protected void generatePolygon( int xPoints[], int yPoints[], int nPoints ) {
	generatePolyline( xPoints, yPoints, nPoints ) ;
        __os.println( "closepath" ) ;
    }

    /** Generates a polyline into the Postscript target.
     *
     * @param xPoints x coordinates of the polyline's points.
     * @param yPoints y coordinates of the polyline's points.
     * @param nPoints the number of points to write.
     */
    protected void generatePolyline( int xPoints[], int yPoints[], int nPoints ) {
	__os.println( "newpath" ) ;
	for (int i = 0; i < nPoints; ++i) {
            generateCoords( xPoints[i], yPoints[i] ) ;
	    if (i == 0) {
		__os.println( "moveto" ) ;
	    }
	    else {
		__os.println( "lineto" ) ;
	    }
        }
    }

}

///////////////////////////////////////////
// XEmacs macros
//
// Local Variables: 
// compile-command: "make -k classesall"
// End: 
