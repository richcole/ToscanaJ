/*
 * Copyright Peter Becker (http://www.peterbecker.de). Please
 * read licence.txt file provided with the distribution for
 * licensing information.
 * 
 * $Id: DecimalValue.java 1825 2005-03-04 22:18:45Z peterbecker $
 */
package org.tockit.datatype.xsd;

import net.sourceforge.toscanaj.model.order.Ordered;

import org.tockit.datatype.AbstractValue;


public class DecimalValue extends AbstractValue {
    private double value;

    public DecimalValue(double value) {
        this.value = value;
    }
    
    public String getDisplayString() {
        return String.valueOf(this.value);
    }

    public boolean isLesserThan(Ordered other) {
        if(other.getClass() != DecimalValue.class) {
            return false;
        }
        DecimalValue otherValue = (DecimalValue) other;
        return otherValue.value > this.value;
    }

    public double getValue() {
        return this.value;
    }
    
    public boolean sameTypeEquals(Object other) {
        DecimalValue otherValue = (DecimalValue) other;
        return otherValue.value == this.value;
    }
    
    public int hashCode() {
        // create hashCode a la java.lang.Double
        long bits = Double.doubleToLongBits(value);
        return (int)(bits ^ (bits >>> 32));
    }
}
