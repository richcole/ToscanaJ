/*
 * Copyright Peter Becker (http://www.peterbecker.de). Please
 * read licence.txt file provided with the distribution for
 * licensing information.
 * 
 * $Id: ConversionException.java 1788 2004-07-03 01:53:29Z peterbecker $
 */
package org.tockit.datatype;


/**
 * Denotes an exception converting between DataValues or from Strings.
 * 
 * This is similar to an IllegalArgumentException, but checked.
 */
public class ConversionException extends Exception {
    public ConversionException() {
        super();
    }

    public ConversionException(String message) {
        super(message);
    }

    public ConversionException(String message, Throwable cause) {
        super(message, cause);
    }

    public ConversionException(Throwable cause) {
        super(cause);
    }
}
