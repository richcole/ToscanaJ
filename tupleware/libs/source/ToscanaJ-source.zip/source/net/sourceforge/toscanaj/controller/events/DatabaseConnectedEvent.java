/*
 * Copyright DSTC Pty.Ltd. (http://www.dstc.com), Technische Universitaet Darmstadt
 * (http://www.tu-darmstadt.de) and the University of Queensland (http://www.uq.edu.au).
 * Please read licence.txt in the toplevel source directory for licensing information.
 *
 * $Id: DatabaseConnectedEvent.java 1830 2005-03-05 10:32:25Z peterbecker $
 */
package net.sourceforge.toscanaj.controller.events;

import net.sourceforge.toscanaj.controller.db.DatabaseConnection;
import org.tockit.events.Event;

public class DatabaseConnectedEvent implements Event {

    private Object source;

    private DatabaseConnection connection;

    public DatabaseConnectedEvent(Object source, DatabaseConnection connection) {
        this.source = source;
        this.connection = connection;
    }

    public Object getSubject() {
        return this.source;
    }

    public DatabaseConnection getConnection() {
        return this.connection;
    }
}
