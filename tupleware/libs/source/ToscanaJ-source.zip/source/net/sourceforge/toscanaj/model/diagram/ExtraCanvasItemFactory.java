/*
 * Copyright Peter Becker (http://www.peterbecker.de). Please
 * read licence.txt file provided with the distribution for
 * licensing information.
 * 
 * $Id: ExtraCanvasItemFactory.java 1731 2004-04-23 08:02:59Z peterbecker $
 */
package net.sourceforge.toscanaj.model.diagram;

import net.sourceforge.toscanaj.util.xmlize.XMLSyntaxError;

import org.jdom.Element;
import org.tockit.canvas.CanvasItem;


public interface ExtraCanvasItemFactory {
    public CanvasItem createCanvasItem(SimpleLineDiagram diagram, Element element) throws XMLSyntaxError ;
}
