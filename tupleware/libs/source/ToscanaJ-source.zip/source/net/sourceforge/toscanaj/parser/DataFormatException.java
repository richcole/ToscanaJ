/*
 * Copyright DSTC Pty.Ltd. (http://www.dstc.com), Technische Universitaet Darmstadt
 * (http://www.tu-darmstadt.de) and the University of Queensland (http://www.uq.edu.au).
 * Please read licence.txt in the toplevel source directory for licensing information.
 *
 * $Id: DataFormatException.java 684 2003-02-03 04:18:30Z peterbecker $
 */
package net.sourceforge.toscanaj.parser;

/**
 * Signals that a file could not be read due to errors in the file itself.
 */
public class DataFormatException extends Exception {
    public DataFormatException() {
    super();
    }

    public DataFormatException(String message) {
    super(message);
    }

    public DataFormatException(String message, Throwable cause) {
        super(message, cause);
    }

    public DataFormatException(Throwable cause) {
        super(cause);
    }
}
