/*
 * Copyright DSTC Pty.Ltd. (http://www.dstc.com), Technische Universitaet Darmstadt
 * (http://www.tu-darmstadt.de) and the University of Queensland (http://www.uq.edu.au).
 * Please read licence.txt in the toplevel source directory for licensing information.
 *
 * $Id: DimensionCreationStrategy.java 532 2002-10-23 05:06:17Z peterbecker $
 */
package net.sourceforge.toscanaj.controller.ndimlayout;

import net.sourceforge.toscanaj.model.lattice.Lattice;

import java.util.Vector;

public interface DimensionCreationStrategy {
    Vector calculateDimensions(Lattice lattice);
}
