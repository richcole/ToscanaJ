/*
* Copyright DSTC Pty.Ltd. (http://www.dstc.com), Technische Universitaet Darmstadt
* (http://www.tu-darmstadt.de) and the University of Queensland (http://www.uq.edu.au).
* Please read licence.txt in the toplevel source directory for licensing information.
*
* $Id: WritableManyValuedContext.java 1788 2004-07-03 01:53:29Z peterbecker $
*/
package net.sourceforge.toscanaj.model.manyvaluedcontext;

import org.tockit.datatype.Datatype;
import org.tockit.datatype.Value;

import net.sourceforge.toscanaj.model.context.*;

public interface WritableManyValuedContext extends ManyValuedContext {
    void add(FCAElement object);
    void add(ManyValuedAttribute attribute);
    void add(Datatype type);
    void remove(FCAElement object);
    void remove(ManyValuedAttribute attribute);
    void remove(Datatype type);
    void setRelationship(FCAElement object, ManyValuedAttribute attribute, Value value);
    void update();
}
