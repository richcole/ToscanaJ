/*
 * Copyright DSTC Pty.Ltd. (http://www.dstc.com), Technische Universitaet Darmstadt
 * (http://www.tu-darmstadt.de) and the University of Queensland (http://www.uq.edu.au).
 * Please read licence.txt in the toplevel source directory for licensing information.
 *
 * $Id: Elba.java 1522 2003-10-16 10:06:12Z peterbecker $
 */
package net.sourceforge.toscanaj;

import net.sourceforge.toscanaj.gui.ElbaMainPanel;

public class Elba {
    /**
     *  Main method for running the program
     */
    public static void main(String[] args) {
    	ToscanaJ.testJavaVersion();
        ToscanaJ.loadPlugins();
        final ElbaMainPanel mainWindow;
        mainWindow = new ElbaMainPanel();
        mainWindow.setVisible(true);
    }
}
