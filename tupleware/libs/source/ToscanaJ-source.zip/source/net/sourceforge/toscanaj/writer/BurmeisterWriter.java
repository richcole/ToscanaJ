/*
 * Copyright Peter Becker (http://www.peterbecker.de). Please
 * read licence.txt file provided with the distribution for
 * licensing information.
 * 
 * $Id: BurmeisterWriter.java 1847 2005-04-27 16:03:44Z peterbecker $
 */
package net.sourceforge.toscanaj.writer;

import java.io.PrintStream;
import java.util.Iterator;

import org.tockit.context.model.Context;

public class BurmeisterWriter {
    public static void writeToBurmeisterFormat(Context context, PrintStream out) {
        // write file ID
        out.println("B");

        // write context summary
        out.println(context.getName());
        out.println(context.getObjects().size());
        out.println(context.getAttributes().size());

        // write objects and attributes
        for (Iterator itOb = context.getObjects().iterator(); itOb.hasNext();) {
            Object object = itOb.next();
            out.println(object.toString());
        }
        for (Iterator itAt = context.getAttributes().iterator(); itAt.hasNext();) {
            Object attribute = itAt.next();
            out.println(attribute.toString());
        }
        
        // write relation
        for (Iterator itOb = context.getObjects().iterator(); itOb.hasNext();) {
            Object object = itOb.next();
            for (Iterator itAt = context.getAttributes().iterator(); itAt.hasNext();) {
                Object attribute = itAt.next();
                if(context.getRelation().contains(object,attribute)) {
                    out.print('x');
                } else {
                    out.print('.');
                }
            }
            out.println();
        }        
        
        out.close();
    }
}
