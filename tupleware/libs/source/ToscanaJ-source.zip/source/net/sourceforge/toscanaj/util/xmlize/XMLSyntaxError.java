/*
 * Copyright DSTC Pty.Ltd. (http://www.dstc.com), Technische Universitaet Darmstadt
 * (http://www.tu-darmstadt.de) and the University of Queensland (http://www.uq.edu.au).
 * Please read licence.txt in the toplevel source directory for licensing information.
 *
 * $Id: XMLSyntaxError.java 749 2003-02-11 09:44:52Z peterbecker $
 */
package net.sourceforge.toscanaj.util.xmlize;

public class XMLSyntaxError extends Exception {
    public XMLSyntaxError(Throwable cause) {
        super(cause);
    }

    public XMLSyntaxError() {
        super();
    }

    public XMLSyntaxError(String reason, Throwable cause) {
        super(reason, cause);
    }

    public XMLSyntaxError(String reason) {
        super(reason);
    }
}
