/*
 * Copyright DSTC Pty.Ltd. (http://www.dstc.com), Technische Universitaet Darmstadt
 * (http://www.tu-darmstadt.de) and the University of Queensland (http://www.uq.edu.au).
 * Please read licence.txt in the toplevel source directory for licensing information.
 *
 * $Id: SQLTypeInfo.java 1830 2005-03-05 10:32:25Z peterbecker $
 */
package net.sourceforge.toscanaj.controller.db;

public class SQLTypeInfo {
	
	private int typeInt;
	private String typeName;
	
	public SQLTypeInfo (int typeInt, String typeName) {
		this.typeInt = typeInt;
		this.typeName = typeName;		
	}
	
	public int getTypeInt() {
		return this.typeInt;
	}

	public String getTypeName() {
		return this.typeName;
	}
	
	public String toString() {
		String str = "SQLTypeInfo: SQL type int = " + this.typeInt + ", name = " + this.typeName;
		return str;
	}

}
