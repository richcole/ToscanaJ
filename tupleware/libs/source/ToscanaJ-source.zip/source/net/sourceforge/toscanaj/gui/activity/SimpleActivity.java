/*
 * Copyright DSTC Pty.Ltd. (http://www.dstc.com), Technische Universitaet Darmstadt
 * (http://www.tu-darmstadt.de) and the University of Queensland (http://www.uq.edu.au).
 * Please read licence.txt in the toplevel source directory for licensing information.
 *
 * $Id: SimpleActivity.java 549 2002-10-28 02:46:23Z peterbecker $
 */
package net.sourceforge.toscanaj.gui.activity;


public interface SimpleActivity {

    /* return success if the activity succeeded, throw an exception
     * if the user should hear that something went wrong.
    */
    public boolean doActivity() throws Exception;
}
