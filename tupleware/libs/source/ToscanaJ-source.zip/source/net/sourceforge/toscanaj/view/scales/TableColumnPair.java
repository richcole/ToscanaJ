/*
 * Copyright DSTC Pty.Ltd. (http://www.dstc.com), Technische Universitaet Darmstadt
 * (http://www.tu-darmstadt.de) and the University of Queensland (http://www.uq.edu.au).
 * Please read licence.txt in the toplevel source directory for licensing information.
 *
 * $Id: TableColumnPair.java 1092 2003-05-01 10:37:42Z peterbecker $
 */
package net.sourceforge.toscanaj.view.scales;

import net.sourceforge.toscanaj.model.database.Column;
import net.sourceforge.toscanaj.model.database.Table;

public class TableColumnPair {
    Table table;
    Column column;

    public TableColumnPair(Table table, Column column) {
        this.table = table;
        this.column = column;
    }

    public Table getTable() {
        return table;
    }

    public Column getColumn() {
        return column;
    }

	public String getSqlExpression() {
		return table.getSqlExpression() + "." + column.getSqlExpression();
	}

	public String toString() {
		return table.getDisplayName() + "." + column.getDisplayName();
	}
}
