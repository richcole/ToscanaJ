#!/bin/sh
ulimit -s 2048
java -jar Elba.jar