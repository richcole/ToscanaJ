#!/bin/sh
ulimit -s 2048
java -jar ToscanaJ.jar $@

