This folder contains libraries from other projects and parties. For 3rd party libraries a licence is provided
as a LICENCE.* file, please read these files. 

Libraries in this folder are needed only for testing code, not for running the program itself.

At the moment it contains:

junit.jar:
  JUnit testing framework (http://www.junit.org, licence in LICENCE.junit)

mockobjects.jar:
  MockObjects test object framework (http://www.mockobjects.com/, licence in LICENCE.mockobjects)
